# cleanup old logs
rm -f /usr/local/nginx/logs/xvs_mp4.txt /usr/local/nginx/logs/xvs_hls.txt

# rename nginx logs
mv -f /usr/local/nginx/logs/traffic_mp4.log /usr/local/nginx/logs/xvs_mp4.txt
mv -f /usr/local/nginx/logs/traffic_hls.log /usr/local/nginx/logs/xvs_hls.txt

#killall -USR1 nginx
# reopen nginx logs
/usr/local/nginx/sbin/nginx -s reopen

# run parsers
[ -s /usr/local/nginx/logs/xvs_mp4.txt ] && ./nginx_http.pl
[ -s /usr/local/nginx/logs/xvs_hls.txt ] && ./nginx_hls.pl
