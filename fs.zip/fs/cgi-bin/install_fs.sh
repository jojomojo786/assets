mkdir temp
mkdir uploads
mkdir orig

if [ $1 ]; then

echo "Special folder $1"
mkdir $1/temp
mkdir $1/uploads
mkdir $1/orig
mkdir $1/i
chmod 777 $1/*
ln -s $1/temp temp/01
ln -s $1/uploads uploads/01
ln -s $1/orig orig/01
ln -s $1/i ../htdocs/i/01

else

mkdir temp/01
mkdir uploads/01
mkdir orig/01
mkdir ../htdocs/i/01

fi


chmod -R 777 temp uploads orig logs ../htdocs/i/01 ../htdocs/i ../htdocs/tmp

wget -q https://sibsoft.net/xvideosharing/ffmpeg2018.tar.xz;tar -xf ffmpeg2018.tar.xz;rm -f ffmpeg2018.tar.xz

chmod 755 *.cgi *.pl *.sh ffmpeg ffprobe
chmod 666 XFSConfig.pm

./ffmpeg