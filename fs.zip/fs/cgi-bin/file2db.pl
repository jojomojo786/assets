#!/usr/bin/perl
use strict;
use XFSConfig;
use LWP::UserAgent;
$|++;
exit if $ENV{REMOTE_ADDR}; # allow only run from console

#sleep(int rand 3600);

my $max_deleted_per_disk = 5;

my ($processed,$deleted,$deleted_total,$size_total);

opendir(DISKS, "$c->{cgi_dir}/uploads") || die("Error:cant open $c->{cgi_dir}: $!");
while( defined(my $fnd=readdir(DISKS)) )
{
   next unless $fnd=~/^\d\d$/;
   ScanDir("$c->{cgi_dir}/uploads/$fnd");
}
$size_total = sprintf("%.01f Gb",$size_total/1024**3);
print"\nTotal deleted files: $deleted_total\nFilesize deleted: $size_total\n";


sub ScanDir
{
   my ($dir) = @_;
   print"\n--- Scan disk dir = $dir\n";

   opendir(DIR, $dir) || die("Error:cant open $dir $!");

   $deleted=0;
   my @arr;
   while( defined(my $fn=readdir(DIR)) ) # read dx dirs
   {
      next if $fn =~ /^\.{1,2}$/;
      next unless -d "$dir/$fn";
      next unless $fn=~/^\d{5}$/;
      opendir(DIR2, "$dir/$fn")||next;
      while( defined(my $fn2=readdir(DIR2)) ) # read files
      {
         next if $fn2 =~ /^\.{1,2}$/;
         my $ftime = (lstat("$dir/$fn/$fn2"))[9];
         next if (time - $ftime) < 3600; # skip last-hour files
         push @arr, "$fn2";
         $processed++;
      }
      closedir(DIR2);

      # del empty dir and go next
      if($#arr==-1)
      {
        my $ftime = (lstat("$dir/$fn"))[9];
        next if (time - $ftime) < 3600*24*3; # do not delete last 3 days empty folders
        print"Del empty dir $dir/$fn\n";
        sleep 1;
        rmdir("$dir/$fn");
        next;
      }

      # if(scalar @arr >= 500)
      # {
      #   processFiles( "$dir/$fn", \@arr );
      #   return if $deleted >= $max_deleted_per_disk;
      #   @arr=();
      #   sleep 1;
      # }
      processFiles( "$dir/$fn", \@arr ) if @arr;
   }
   closedir(DIR);

   print"Files removed from disk: $deleted\n\n";
}

sub processFiles
{
   my ($dir, $arr) = @_;

      my $ua = LWP::UserAgent->new(agent => $c->{user_agent},timeout => 360);

      print"$processed.\n";
      my $res = $ua->post("$c->{site_cgi}/fs.cgi",
                          {
                             dl_key => $c->{dl_key},
							 #host_id => $c->{host_id},
                             op     => 'check_codes',
                             codes  => join(',', @$arr ),
                          }
                         );

      die("Error: fs bad answer: ".$res->content) unless $res->content=~/^OK/;
      my ($bad) = $res->content=~/^OK:(.+?)$/;
      #die join(',', @$arr );
      for( split(/\,/,$bad) )
      {
         return if $deleted >= $max_deleted_per_disk;
         #print("srv_id collision! $dir/$_\n"),next if $_=~/\!$/;
         print"DEL $dir/$_\n";
         $size_total += -s "$dir/$_";
         unlink("$dir/$_") || print"can't delete $dir/$_: $!\n";
         $deleted++;
         $deleted_total++;
      }
}