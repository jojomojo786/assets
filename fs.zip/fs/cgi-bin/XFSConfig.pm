package XFSConfig;
use strict;
use lib 'Modules';
$ENV{PERL_LWP_SSL_VERIFY_HOSTNAME}=0;
use Exporter ();
@XFSConfig::ISA    = qw(Exporter);
@XFSConfig::EXPORT = qw($c);
use vars qw( $c );

$c=
{
### Manually configure keys below ###
 cgi_dir => '/var/www/cgi-bin',

 htdocs_dir => '/var/www/htdocs',

 # nginx port (to parse number of current connections)
 nginx_port => '80',

#####################################

 dl_key => '',

 user_agent => '',

 main_server_ip => '',

 host_id => '',

 # Your Main site URL, witout trailing /
 site_url => '',

 # Your Main site cgi-bin URL, witout trailing /
 site_cgi => '',

#--- Anonymous users limits ---#
 enabled_anon => '',

 # Maximum upload Filesize in Mbytes (0 to disable)
 max_upload_filesize_anon => '',

 # Allow remote URL uploads
 remote_url_anon => '',
#------#

#--- Registered users limits ---#
 enabled_reg => '1',

 # Maximum upload Filesize in Mbytes (0 to disable)
 max_upload_filesize_reg => '500',

 # Allow remote URL uploads
 remote_url_reg => '1',
#------#

#--- Premium users limits ---#
 enabled_prem => '1',

 # Maximum upload Filesize in Mbytes (0 to disable)
 max_upload_filesize_prem => '1000',

 # Allow remote URL uploads
 remote_url_prem => '1',
#------#

 # Empty to disable logs
 uploads_log => 'logs.txt',

 # Banned IPs
 # Use \d+ for wildcard *
 ip_not_allowed => '',

 #Files per dir, do not touch since server start
 files_per_folder => 5000,

 m_x => '',
 m_x_width => '1280',
 m_x_rows => '3',
 m_x_logo => 'XVideoSharing',
 m_x_prem_only => '',
 m_x_th_width => '500',
 m_x_th_height => '500',

 # Video extensions
 video_extensions => 'avi|mkv|mpg|mpeg|vob|wmv|flv|mp4|mov|m4v|m2v|divx|xvid|3gp|webm|ogv|ogg',

 # max enc.pl processes
 host_max_enc => '1',

 # max transfer.pl processes
 host_max_trans => '1',

 # max upload_url.pl processes
 host_max_url => '1',

 ### Torrent settings ###
 m_t => '',
 torrent_srv_id => '1',
 torrent_disk_id => '01',
 ########################

 m_z => '',
 m_z_cols => '5',
 m_z_rows => '5',

 thumb_width => '200',
 thumb_height => '112',
 thumb_position => '30%',

 save_html_results => '1',

 srt_auto => '',

 custom_snapshot_upload => '300',

 m_f_sync_files_after => '3',

 thumb_quality => '80',

 zevera_client_id => '',
 zevera_pin => '',
 
 no_ffmpeg_timeout => '1',

 updatedb_on_failed_transfer => '',

};

1;
