#!/usr/bin/perl
use strict;
use XFSConfig;
use LWP::UserAgent;

exit if $ENV{REMOTE_ADDR}; # allow only run from console

my @xx=`ps ax|grep transfer.pl`;
@xx = grep {$_!=$$} map{/^\s*(\d+)/;$1} grep{/perl/} @xx;
print join("\n", @xx),"\n";
print("reached max processes list\n"),exit if scalar(@xx)>=$c->{host_max_trans};

my $cx;
my $ua  = LWP::UserAgent->new(agent => $c->{user_agent}, timeout => 360);
my $ua2 = LWP::UserAgent->new(agent => $c->{user_agent}, timeout => 5);

require Log;
my $log = Log->new(filename=>'transfer.txt');

my ($disk_id,$real_id,$code,$links);
my ($current_bytes,$old_size,$old_time);

while($cx++<100)
{
   my $str = $ua->post("$c->{site_url}/dl",
                       {
                       op           => "queue_transfer_next",
                       dl_key       => $c->{dl_key},
                       host_id      => $c->{host_id},
                       }
                      )->content;

   print(".$str\n"),sleep(1+$c->{host_max_trans}*5),next unless $str;
   $log->log("FS:$str");
   ($disk_id,$real_id,$code,$links)=$str=~/^(\d+):(\d+):(\w+)\n(.+)$/s;
   sleep(10),next unless $code;

   my $dx = sprintf("%05d",$real_id/$c->{files_per_folder});
   my $error;
   my $upload_dir = "$c->{cgi_dir}/uploads";

   ($current_bytes,$old_size,$old_time)=(0,0,0);

   for( split(/\n/,$links) )
   {
      my ($type,$url) = split(/=/,$_);
      my ($fname) = $url=~/\/([^\/]+)$/;
      my $dir="$upload_dir/$disk_id/$dx" if $type eq 'ENC';
      $dir="$c->{cgi_dir}/orig/$disk_id/$dx" if $type eq 'ORIG';
      $dir="$c->{htdocs_dir}/i/$disk_id/$dx" if $type=~/^(SNAP|SNAPTH|IMG)$/;
      unless(-d $dir)
      {
         my $mode = 0777;
         mkdir $dir, $mode;
         chmod $mode,$dir;
      }

    ### Get filesize ###
    my $request  = HTTP::Request->new( HEAD => $url );
    my $link_size = $ua->request( $request )->content_length;
    print"SIZE:$link_size\n";
    ####################

      my $file="$dir/$fname";
      print"DL-$type $url to $file\n";
      if(-f $file)
      {
      	print("$code $type: already have on disk same size"),next if $link_size == -s $file;
      	print("$code $type: already have on disk just modified"),next if time-(lstat($file))[9] < 180;
      }

      #my $res = $ua->get( $url , ':content_file'=>$file );
      open FILE, ">$file";
      my $res = $ua->get( $url , ':content_cb'=>\&hook_url, ':read_size_hint' => 2*1024*1024 );
      close FILE;
      my $fsize = -s $file;
      $log->log("Received size: $fsize of $link_size");
      if(!$res->is_success || !-e $file || $fsize<50 || $fsize < $link_size)
      {
         if(!$res->is_success)
         {
		$log->log("ERROR: $type:".$res->status_line);
		$error.="$type: returned ".$res->status_line if $type=~/^(ENC)$/i; #|ORIG
         }
         else
         {
         	$log->log("ERROR: $type: file size error: $fsize < $link_size");
         	if($url=~/_(n|h|l|o)$/ && $c->{updatedb_on_failed_transfer})
			{
			 my $res = postMain({
			                   op              => "update_file_data",
			                   file_real_id    => $real_id,
			                   file_code       => $code,
			                   "file_size_$1"  => 0,
			                   });
			 $log->log("Updated $1 size to 0:$res");
			 next;
			}
		$error.="$type: received $fsize instead of $link_size" if $type=~/^(ENC)$/i; #|ORIG
         }
         unlink($file) if -e $file && $fsize<50;
      }
      #sleep 1;
      last if $error;
   }

sub hook_url
{
  my ($buffer) = @_;
  print FILE $buffer;
  $current_bytes+=length($buffer);
  
  if(time>$old_time+15)
  {
     my $speed_kb = sprintf("%.0f", ($current_bytes-$old_size)/1024/(time-$old_time) );
     $old_time = time;
     $old_size = $current_bytes;
     $ua2->post("$c->{site_url}/dl",
                 {
                 op              => "transfer_progress",
                 dl_key          => $c->{dl_key},
                 file_real_id    => $real_id,
                 file_real       => $code,
                 transferred     => $current_bytes,
                 speed           => $speed_kb,
                 })->content;
  }
}

   unless($error)
   {
      my $str = postMain( {
                          op           => "queue_transfer_done",
                          file_real_id => $real_id,
                          file_real    => $code,
                          }
                         );
      print"Update DB: $str\n";
   }
   else
   {
      my $str = postMain(
                          {
                          op           => "transfer_error",
                          file_real_id => $real_id,
                          file_real    => $code,
                          error        => $error,
                          }
                         );
      print"Had errors, sent report: $str\n";
   }

   sleep 1;
}

sub postMain
{
	my ($data) = @_;
	$data->{dl_key} = $c->{dl_key};
	my $uax  = LWP::UserAgent->new(agent => $c->{user_agent}, timeout => 360);
	my $try=0;
	LOOP:
	$try++;
	my $res = $uax->post("$c->{site_cgi}/fs.cgi", $data );
	unless($res->content=~/^OK/)
	{
		$log->log("fs.cgi error: ".$res->status_line." : ".$res->content);
		if($try<=3){sleep(2);goto LOOP;}
	}
	
	return $res->content;
}
