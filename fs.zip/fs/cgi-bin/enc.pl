#!/usr/bin/perl
use strict;
use XFSConfig;
use LWP::UserAgent;
use File::Copy;
use XUpload;
exit if $ENV{REMOTE_ADDR}; # allow only run from console

my $restart;
$SIG{HUP} = sub { $restart=1 };

my @xx=`ps ax|grep enc.pl`;
@xx = grep {$_!=$$} map{/^\s*(\d+)/;$1} grep{/perl/} @xx;
print join("\n", @xx),"\n";
print("reached max processes list\n"),exit if scalar(@xx)>=$c->{host_max_enc};

$SIG{ALRM} = sub {
   kill -9, $$;
};

$c->{ffmpeg}||="$c->{cgi_dir}/ffmpeg";

require Log;
my $log = Log->new(filename=>'enc.txt');

my ($cx,$length_changed);
while($cx++<1000)
{
   print("Exiting on signal"),exit if $restart;

   my $ua = LWP::UserAgent->new(agent => $c->{user_agent}, timeout => 90);

   my $str = $ua->post("$c->{site_url}/dl",
                       {
                       op           => "queue_enc_next",
                       dl_key       => $c->{dl_key},
                       host_id      => $c->{host_id},
                       }
                      )->content;
   print"$str\n";

 $str=~s/[\n\r]+//g;
 print(".\n"),sleep(1+$c->{host_max_enc}*4),next unless $str;
 print $str,"\n";

 require JSON;
 my $dd = JSON::decode_json($str);

 my ($disk_id,$real_id,$file_real,$type,$video_settings) = ($dd->{disk_id},$dd->{file_real_id},$dd->{file_real},$dd->{type},$dd->{settings});
 
 print"Disk:$disk_id  file_real_id:$real_id file_real:$file_real type:$type\n";
 if($file_real eq 'RESTART')
 {
    print("Exiting on restart...\n");
    `killall -HUP enc.pl`;
    exit;
 }

 sleep(10),next unless $file_real;

 my $dx = sprintf("%05d",$real_id/$c->{files_per_folder});
 my $dir_orig  = "$c->{cgi_dir}/orig/$disk_id/$dx";
 my $dir_uploads  = "$c->{cgi_dir}/uploads/$disk_id/$dx";
 my $file = "$c->{cgi_dir}/orig/$disk_id/$dx/$file_real";
 print"FILE:$file\n";

 unless(-d $dir_uploads)
 {
    my $mode = 0777;
    mkdir $dir_uploads, $mode;
    chmod $mode, $dir_uploads;
 }

 sleep(10) unless -e $file; # Hack for long-processing videos
 # Hack for re-encode when no Original exist
 move("$dir_uploads/$file_real\_h",$file) if !-f $file && -f "$dir_uploads/$file_real\_h";
 move("$dir_uploads/$file_real\_n",$file) if !-f $file && -f "$dir_uploads/$file_real\_n";
 move("$dir_uploads/$file_real\_l",$file) if !-f $file && -f "$dir_uploads/$file_real\_l";
 unless(-e $file)
 {
     $log->log("Source file not found: $file. Skipping.");
     sendError($real_id,"Source file not found: $file");
     next;
 }

 my $vdata={};
 XUpload::getVideoInfo($file,$vdata);

 $video_settings->{$_}=$vdata->{$_} for keys %$vdata;
 my $vfps = $vdata->{ID_VIDEO_FPS};
 my $length = $vdata->{ID_LENGTH};
 my ($width,$height) = ($vdata->{ID_VIDEO_WIDTH},$vdata->{ID_VIDEO_HEIGHT});
 $video_settings->{srt} = $vdata->{srt};
 $video_settings->{vid_audio_bitrate} = $vdata->{ID_AUDIO_BITRATE} if $vdata->{ID_AUDIO_BITRATE} && $vdata->{ID_AUDIO_BITRATE} < $video_settings->{vid_audio_bitrate};
 $video_settings->{vid_audio_rate} = $vdata->{ID_AUDIO_RATE} if $vdata->{ID_AUDIO_RATE} && $vdata->{ID_AUDIO_RATE} < $video_settings->{vid_audio_rate};

 # VOB aspect ratio fix
 if($vdata->{file_spec_txt}=~/Video: mpeg2/i)
 {
    my ($a1,$a2) = $vdata->{file_spec_txt}=~/DAR (\d+):(\d+)/;
    $height = sprintf("%.0f", $width * $a2 / $a1 );
 }

 print"($width x $height)($length secs)\n";

 unless($width && $height && $length)
 {
     $log->log("Can't parse video info for $file: $vdata->{file_spec_txt}");
     sendError($real_id,"Can't parse video info for $file");
     next;
 }

 my $filenew = "$dir_uploads/$file_real\_$type";
 if(-s $filenew && !$video_settings->{reencode})
 {
	$log->log("File $filenew already exist and its not reencode. Skipping.");
	next;
 }
 # if(-s "$dir_uploads/$file_real\_$type")
 # {
 #    my $mtime = (lstat("$dir_uploads/$file_real\_$type"))[9];
 #    my $mdt = time - $mtime;
 #    next if $mdt < 60; # skip if result file already exist and fresh, avoid dupe encodings
 # }

 my $error;
 $length_changed=0;
 if($type eq 'p')
 {
    $error = EncodePreview( $disk_id,$dx,$dir_orig,$dir_uploads,$file_real,$real_id,$type,$width,$height,$length,$vfps, $video_settings );
 }
 else
 {
    $error = EncodeVideo( $disk_id,$dx,$dir_orig,$dir_uploads,$file_real,$real_id,$type,$width,$height,$length,$vfps, $video_settings );
 }
 
 if($error)
 {
     $log->log("Enc error:$error");
     unlink("$dir_orig/$file_real\_$type.mp4");
     unlink($filenew);
     sendError($real_id,$error);
     next;
 }

 my $file_size = -s $filenew;
 print"Filesize:$file_size\n";

 my $vinfo;
 $vinfo->{vid_container} = $video_settings->{vid_container};
 my $file_spec = XUpload::getVideoInfo($filenew,$vinfo);

 my $length2 = $vinfo->{ID_LENGTH} if $length_changed;

 my $ua = LWP::UserAgent->new(agent => $c->{user_agent}, timeout => 90);

 my $res = $ua->post("$c->{site_cgi}/fs.cgi",
                     {
                     op              => "queue_enc_done",
                     dl_key          => $c->{dl_key},
                     file_real_id    => $real_id,
                     quality         => $type,
                     file_size       => $file_size,
                     file_real       => $file_real,
                     length_new      => $length2,
                     file_spec       => $file_spec,
                     }
                    )->content;
 print"FS:$res\n";
 sleep 1;
}


############################
# sub genFFMPEGparams
# {
#     my ($file,$settings) = @_;
# }
sub EncodeVideo
{
 my ($disk_id,$dx,$dir,$dir_uploads,$code,$real_id,$type,$width,$height,$length,$vfps, $settings) = @_;

 $settings->{'length'} = $length; # for watermark only

 return "Qmode=$settings->{vid_quality_mode}, Arate=$settings->{vid_audio_bitrate}" unless $settings->{vid_quality_mode} && $settings->{vid_audio_bitrate};

 my $audio_channels = $settings->{vid_audio_channels} ? "-ac $settings->{vid_audio_channels}" : ""; # Mono/Stereo or default

 my $file = "$dir/$code";
 unless(-f $file)
 {
    $dir = $dir_uploads; # try to use encoded file as a source
    return "File not found on disk: $file" unless -f $file;
 }

 #print"* JOB: $m_e_vid_width:$m_e_vid_height pix, Q:$m_e_vid_quality, A:$m_e_audio_bitrate, AC: $audio_channels MODE: $extra\n";
 #print"Settings:\n";
 #print"$_\t$settings->{$_}\n" for keys %$settings;

 my $extra="_$type";

 my $audio_kbps = $settings->{vid_audio_bitrate}.'k';

 my $enc_mode;
 if($settings->{vid_quality_mode} eq 'crf')
 {
     $enc_mode="-crf $settings->{vid_quality}";
 }
 else
 {
     $enc_mode="-b:v $settings->{vid_bitrate}k";
 }

 my $fpsnew = 30 if $vfps>30;
 $fpsnew = $settings->{vid_fps} if $settings->{vid_fps}=~/^\d+$/;
 my $gop = sprintf("%.0f", ($fpsnew||$vfps) * 5 ); # I-frame each 5 seconds
 my $fps_limit="-g $gop" if $gop; # -x264opts no-scenecut
 $fps_limit.=" -r $fpsnew" if $fpsnew;

 #my $fpre = "Modules/presets/libx264-$settings->{vid_vpre}.ffpreset" if $settings->{vid_vpre};
 $settings->{vid_preset}||='medium';

 my ($resize_w,$resize_h) = $settings->{vid_resize}=~/^(\d*)x(\d*)$/;
 my ($wnew,$hnew) = makeNewSize( $width,$height, $resize_w,$resize_h );
 print"Video resize: $wnew:$hnew pixels\n";

 my @vf;
 push @vf, "yadif" if $settings->{deinterlace};

 if($settings->{cropl} || $settings->{cropt} || $settings->{cropr} || $settings->{cropb} || $settings->{crop_auto})
 {
    if($settings->{crop_auto})
    {
        my $x = `$c->{ffmpeg} -ss 5 -i $file -t 1 -an -sn -vf cropdetect=30:2 -y /tmp/crop.mp4 2>&1`;
        print"$x\n";
        my ($cw,$ch,$cdx,$cdy) = $x=~/crop=(\d+):(\d+):(\d+):(\d+)/i;
        print"CROP:($cw,$ch,$cdx,$cdy)\n";
        push @vf, "crop=$cw:$ch:$cdx:$cdy";
        $wnew = $cw;
        $hnew = $ch;
    }
    else
    {
        $settings->{cropl}||=0;
        $settings->{cropt}||=0;
        my $dxx = $settings->{cropl}+$settings->{cropr};
        my $dyy = $settings->{cropt}+$settings->{cropb};
        push @vf, "crop=in_w-$dxx:in_h-$dyy:$settings->{cropl}:$settings->{cropt}";
        $wnew = $wnew-$dxx;
        $hnew = $hnew-$dyy;
    }
 }

 push @vf, "hue='s=0'" if $settings->{grayscale};
 push @vf, "transpose=$settings->{rotate}" if $settings->{rotate}=~/^(1|2)$/;
 push @vf, "scale=$wnew:$hnew" if $wnew && $hnew;
 push @vf, "hqdn3d=2:2:6:6" if $settings->{denoise};
 push @vf, "subtitles=$file" if $settings->{srt_burn} && $settings->{srt};

 my $videofilters = $settings->{watermark_mode} ? configureWatermark($settings,@vf) : @vf ? '-vf "'.join(',', @vf).'"' : '';

 #-vsync 1
 my $flags = '-movflags faststart';
 $flags .= " -pix_fmt yuv420p"; # better compatibility and less errors
 $flags .= ' -sws_flags lanczos' if $settings->{vid_resize_method}; # better-slower resize for geeks
 $flags .= " -af 'volume=$settings->{volume}'" if $settings->{volume}=~/^[\d\.]+$/;
 $flags .= " -map_chapters -1 -map_metadata -1"; # -map 0:v:0 -map 0:a:0  or -map 0:0 -map 0:1
 #$flags .= " -map $settings->{video_map}" if $settings->{video_map};
 #$flags .= " -map $_" for @{$settings->{audio_map}};
 if($settings->{vid_crf_bitrate_max}=~/^\d+$/)
 {
    $settings->{vid_crf_bitrate_max} = int($settings->{vid_crf_bitrate_max} * $hnew / $resize_h) if $resize_h && $hnew < $resize_h; # hack for lower resolutions
    my $bufsize = $settings->{vid_crf_bitrate_max}*5; # 5 seconds limit interval
    $flags .= " -maxrate $settings->{vid_crf_bitrate_max}k -bufsize $bufsize".'k';
 }

 if($settings->{tt1}=~/^[\d\:\.]+$/)
 {
    $settings->{tt1}=$1*3600 + $2*60 + $3 if $settings->{tt1}=~/^(\d+):(\d+):(\d+)$/;
    $settings->{tt1}=$1*60 + $2 if $settings->{tt1}=~/^(\d+):(\d+)$/;
    $flags .= " -ss $settings->{tt1}";
    $length_changed=1;
 }
 if($settings->{tt2}=~/^[\d\:\.]+$/ && $settings->{tt1}=~/^[\d\.]*$/)
 {
    $settings->{tt2}=$1*3600 + $2*60 + $3 if $settings->{tt2}=~/^(\d+):(\d+):(\d+)$/;
    $settings->{tt2}=$1*60 + $2 if $settings->{tt2}=~/^(\d+):(\d+)$/;
    $flags .= " -t ".($settings->{tt2}-$settings->{tt1});
    $length_changed=1;
 }
 # if($settings->{vid_mobile_support})
 # {
 #    $flags .= " -profile:v main -level 3.1";
 # }
 
 my $audio_rate = "-ar $settings->{vid_audio_rate}" if $settings->{vid_audio_rate};
 my $audio_codec = 'aac';

 my $file_enc = "$c->{cgi_dir}/temp/$disk_id/$code\_$type.mp4";

 # -g 50 - I-frame every 50 frames
 # -async 1 (before -i)
 my $timeout='timeout -s 9 3h ' unless $c->{no_ffmpeg_timeout};
 my $ffmpeg_string;
 if($settings->{transcode_video}) # Just transcode video
 {
    my $audio_transcode = $settings->{transcode_audio} ? "-c:a copy" : "-c:a $audio_codec $audio_rate -b:a $audio_kbps $audio_channels";
    $ffmpeg_string="$timeout$c->{ffmpeg} -analyzeduration 6000M -probesize 2147M -vsync 2 -i $file -max_muxing_queue_size 9999 -y $audio_transcode -c:v copy -threads 1 -movflags faststart -map_chapters -1 -map_metadata -1 $file_enc";
 }
 elsif($type eq 'h') # High Quality options
 {
    $ffmpeg_string="$timeout$c->{ffmpeg} -analyzeduration 6000M -probesize 2147M -vsync 2 -i $file -max_muxing_queue_size 9999 -y -c:a $audio_codec $audio_rate -b:a $audio_kbps $audio_channels -c:v libx264 -preset $settings->{vid_preset} $fps_limit $enc_mode $videofilters -threads 0 $flags $file_enc";
 }
 elsif($type eq 'l') # Low Quality options
 {
     # -profile:v baseline
    $ffmpeg_string="$timeout$c->{ffmpeg} -analyzeduration 6000M -probesize 2147M -vsync 2 -i $file -max_muxing_queue_size 9999 -y -c:a $audio_codec $audio_rate -b:a $audio_kbps $audio_channels -c:v libx264 -preset $settings->{vid_preset} $fps_limit $enc_mode $videofilters -threads 0 $flags -profile:v main -level 3.1 $file_enc";
 }
 else # Normal/Other Quality options
 {
    $ffmpeg_string="$timeout$c->{ffmpeg} -analyzeduration 6000M -probesize 2147M -vsync 2 -i $file -max_muxing_queue_size 9999 -y -c:a $audio_codec $audio_rate -b:a $audio_kbps $audio_channels -c:v libx264 -preset $settings->{vid_preset} $fps_limit $enc_mode $videofilters -threads 0 $flags $file_enc";
 }

 print"ENC STR: $ffmpeg_string\n";

 alarm(3600); # fire alarm after 1 hour
 $/="\r";
 open F, "$ffmpeg_string 2>&1|";
 my $ua2 = LWP::UserAgent->new(agent => $c->{user_agent}, timeout => 5);
 my $t=0;
 my $last;
 my $enc_update_time = 10;
 while(<F>)
 {
    #print"$_\n";
    $last=$_;
    next if time < ($t+$enc_update_time);
    next unless $_=~/frame=/i;
    $t=time;
    my ($ct,$ctt) = $_=~/time=([\d\:]+)\.(\d+)/i;
    my ($fps) = $_=~/fps=\s*(\d+)/i;
    $ct = $1*3600 + $2*60 + $3 if $ct=~/^(\d+):(\d+):(\d+)$/;
    $ct+=sprintf("%.0f",$ctt/100);
    my $res = $ua2->post("$c->{site_url}/dl",
                       {
                       op              => "enc_progress",
                       dl_key          => $c->{dl_key},
                       file_real_id    => $real_id,
                       progress        => sprintf("%.0f",100*$ct/$length),
                       fps             => $fps||0,
                       quality         => $type,
                       }
                       );
 }
 $/="\n";
 alarm(0); # stop alarm

 print"LAST:$last\n";
 unless($last=~/video:\d+/is)
 {
    $log->log("Error while encoding file $file : $last");
    $last=(split(/\n/,$last))[-1];
    sendError($real_id,$last);
    unlink($file_enc);
    next;
 }

 my $fsize = -s $file_enc;
 print"Fsize:$fsize\n";
 
 unless($fsize)
 {
    $log->log("Error while encoding file $file : zero filesize");
    sendError($real_id,"zero filesize");
    #unlink($file_enc);
    next;
 }

 # if($c->{mp4box_path})
 # {
 #     my $inter = 1000; # interleaving 1 second
 #     $inter=2000 if $length > 60 * 5;
 #     $inter=3000 if $length > 60 * 20;
 #     $inter=5000 if $length > 60 * 60;
 #     $c->{mp4box_path}||='MP4Box';
 #     #my @rr = `$c->{mp4box_path} -add $dir/$code$extra.mp4 -isma -inter $inter $dir/$code$extra.mp4x`;
 #     my @rr = `$c->{mp4box_path} -isma -inter $inter $dir/$code$extra.mp4`;
 #     print join '',@rr;
 #     #return "Can't MP4Box $dir/$code$extra.mp4: ".join('',@rr) unless -s "$dir/$code$extra.mp4x";
 # }

 if($settings->{vid_container} eq 'flv')
 {
    my $rr = `$c->{cgi_dir}/yamdi -c XVideoSharing -i $file_enc -o $dir/$code.flv 2>&1`;
    print"YAMDI:$rr\n";
    print"Can't yamdi $file_enc: $rr\n" unless -s "$dir/$code.flv";
    move("$dir/$code.flv",$file_enc) if -e "$dir/$code.flv";
 }

 if(-s $file_enc)
 {
    move($file_enc,"$dir_uploads/$code$extra") || return "can't rename $file_enc to $dir_uploads/$code$extra : $!";
    print"renamed $file_enc to $dir_uploads/$code$extra\n\n";
 }

 unlink($file_enc);

 if( $c->{m_z} && $type eq 'n')
 {
    my $rand = join '', map int rand 10, 1..7;
    my $temp_dir = "$c->{cgi_dir}/temp/$rand";
    mkdir $temp_dir, 0777;

    my $idir = "$c->{htdocs_dir}/i/$disk_id/$dx";
    unless(-d $idir)
    {
       mkdir $idir,0777;
       chmod 0777, $idir;
    }

    XUpload::createTimeslides( $file, { file_code => $code, file_length => $length }, {}, $temp_dir, $idir );

    rmdir($temp_dir);

    # #my $bgcolor='#191919';
    # my $slide_size = '108x60';

    # my $frames=$c->{m_z_cols}*$c->{m_z_rows};
    # for my $i (1..$frames)
    # {
    #    my $ss = sprintf("%.1f",$i*$length/($frames+1));
    #    my $th = "$temp_dir/".sprintf("%03d",$i);
    #    my $thp = "$temp_dir/p".sprintf("%03d",$i);
    #    XUpload::makeSnap( $file, "$th\_s.png", $ss, $c->{thumb_width}, $c->{thumb_height}, 'fast');
    #    copy("$th\_s.png","$th\_p.png");
    # }
    
    # `mogrify -thumbnail '$slide_size' $temp_dir/*_s.png`;
    
    # #-background "$bgcolor"
    # my $zfile = "$idir/$code"."0000.jpg";
    # `montage $temp_dir/*_s.png -tile $c->{m_z_cols}x -geometry +0+0 $zfile`;
    # $log->log("Saved slide image to $idir/$code"."0000.jpg");

    # `montage $temp_dir/*_p.png -tile $c->{m_z_cols}x -geometry +0+0 $idir/$code\_p.jpg`;
    # $log->log("Saved big-slide image to $idir/$code\_p.jpg"); #transfer/del

    # unlink(<$temp_dir/*.png>);
    # unlink(<$temp_dir/*.jpg>);
    # rmdir($temp_dir);
 }

 return 0;
}
############################

sub makeNewSize
{
    my ($width,$height, $resize_w,$resize_h) = @_;
    my ($wnew,$hnew);
    if($resize_w && !$resize_h)
    {
        $wnew = $resize_w<$width ? $resize_w : $width;
        $hnew = sprintf("%.0f", ($height * $wnew/$width) );
    }
    elsif(!$resize_w && $resize_h)
    {
        $hnew = $resize_h<$height ? $resize_h : $height;
        $wnew = sprintf("%.0f", ($width * $hnew/$height) );
    }
    elsif(!($resize_w || $resize_h) || ($width<=$resize_w && $height<=$resize_h) )
    {
        # empty resize parameters or video is smaller both sides - no resize
        $wnew = $width;
        $hnew = $height;
    }
    else
    {
        $wnew = $resize_w;
        $hnew = sprintf("%.0f", ($height * $resize_w/$width) );

        if($hnew > $resize_h)
        {
            $wnew = sprintf("%.0f", ($width * $resize_h/$height) );
            $hnew = $resize_h;
        }
    }

    # Improve size for better compression
    my $block=4; # block size. possible values: 2,4,8,16,32
    $wnew = sprintf("%.0f", $wnew / $block) * $block;
    $hnew = sprintf("%.0f", $hnew / $block) * $block;    
    return ($wnew,$hnew);
}

sub configureWatermark
{
    my ($settings,@vf) = @_;
    my $watermark;
    my $vff = join(',', @vf); 
    $vff = $vff.',' if $vff;
     if($settings->{watermark_mode} eq 'text')
     {
         my $x = $settings->{watermark_padding} if $settings->{watermark_position}=~/^(nw|w|sw)$/i;
         $x = '(w-tw)/2' if $settings->{watermark_position}=~/^(n|c|s)$/i;
         $x = 'w-tw-'.$settings->{watermark_padding} if $settings->{watermark_position}=~/^(ne|e|se)$/i;

         my $y = $settings->{watermark_padding} if $settings->{watermark_position}=~/^(nw|n|ne)$/i;
         $y = '(h-th)/2' if $settings->{watermark_position}=~/^(w|c|e)$/i;
         $y = 'h-th-'.$settings->{watermark_padding} if $settings->{watermark_position}=~/^(sw|s|se)$/i;

         my $draw = 1;
         $draw = '(lt(t\,'.$settings->{watermark_dispose_time}.')+gt(t\,'.($settings->{'length'}-$settings->{watermark_dispose_time}).'))' if $settings->{watermark_dispose_mode} eq 'start_end';
         $draw = 'lt(mod(t\,'.$settings->{watermark_dispose_blink1}.')\,'.$settings->{watermark_dispose_blink2}.')' if $settings->{watermark_dispose_mode} eq 'blink';

         my $shadow=":shadowy=1:shadowx=1:shadowcolor=$settings->{watermark_shadow_color}\@$settings->{watermark_opacity}" if $settings->{watermark_shadow_color};
         my $font="Modules/fonts/font_$settings->{watermark_font}.ttf" if -f "Modules/fonts/font_$settings->{watermark_font}.ttf";

         $watermark=qq[-vf "$vff drawtext=fontfile=$font:fontsize=$settings->{watermark_size}:fontcolor=$settings->{watermark_color}\@$settings->{watermark_opacity}$shadow:x=$x:y=$y:enable=$draw:text=$settings->{watermark_text}"]
             if $font && $settings->{watermark_text};
     }
     if($settings->{watermark_mode} eq 'scroll')
     {
         my $y = $settings->{watermark_padding} if $settings->{watermark_position} eq 'top';
         $y = '(h-th)/2' if $settings->{watermark_position} eq 'middle';
         $y = 'h-th-'.$settings->{watermark_padding} if $settings->{watermark_position} eq 'bottom';

         my $shadow=":shadowy=1:shadowx=1:shadowcolor=$settings->{watermark_shadow_color}\@$settings->{watermark_opacity}" if $settings->{watermark_shadow_color};

         my $mod = int $settings->{watermark_scroll_start}+$settings->{watermark_scroll_length}*1.5;
         my $x = "(w-(mod(t\\,$mod)-$settings->{watermark_scroll_start})*w/$settings->{watermark_scroll_length})";
         my $font="Modules/fonts/font_$settings->{watermark_font}.ttf" if -f "Modules/fonts/font_$settings->{watermark_font}.ttf";

         $watermark=qq[-vf "$vff drawtext=fontfile=$font:fontsize=$settings->{watermark_size}:fontcolor=$settings->{watermark_color}\@$settings->{watermark_opacity}$shadow:x=$x:y=$y:text=$settings->{watermark_text}"]
             if $font && $settings->{watermark_text};
     }
     if($settings->{watermark_mode} eq 'image' && $settings->{watermark_image_url})
     {
         my $logo = "$c->{htdocs_dir}/i/watermark_$settings->{usr_id}.png";
         my $watermark_mov = "$c->{htdocs_dir}/i/watermark_$settings->{usr_id}.mov";
         my $watermark_logo;
         my $wsize = -s $logo;
         $settings->{watermark_padding}||=0;
         if($wsize != $settings->{watermark_image_size} || (!-f $watermark_mov && $settings->{watermark_fade}))
         {
             my $ua = LWP::UserAgent->new(timeout => 90);
             my $res = $ua->get( $settings->{watermark_image_url}, ':content_file' => $logo );
             #print $res->content,"\n";
             if(-f $logo && $settings->{watermark_fade})
             {
                 my $fadeout_frames = 30; # fadeout length is about 1 sec
                 my $frames = 24 * $settings->{watermark_image_fadeout} + 1; # assuming 24 FPS
                 my $fade_start = $frames - $fadeout_frames - 1;
                 my $ffmpeg_mov=qq[$c->{ffmpeg} -y -loop 1 -i $logo -vframes $frames -vf "fade=out:$fade_start:$fadeout_frames:alpha=1" -vcodec png -pix_fmt rgba $watermark_mov];
                 print"FFMOV:$ffmpeg_mov\n";
                 `$ffmpeg_mov`;
             }
         }
         if(-f $watermark_mov && $settings->{watermark_fade})
         {
              $watermark_logo = $watermark_mov;
         }
         elsif(-f $logo)
         {
            $watermark_logo = $logo;
         }
         my $x = $settings->{watermark_padding} if $settings->{watermark_position}=~/^(nw|w|sw)$/i;
         $x = '(main_w-overlay_w)/2' if $settings->{watermark_position}=~/^(n|c|s)$/i;
         $x = 'main_w-overlay_w-'.$settings->{watermark_padding} if $settings->{watermark_position}=~/^(ne|e|se)$/i;

         my $y = $settings->{watermark_padding} if $settings->{watermark_position}=~/^(nw|n|ne)$/i;
         $y = '(main_h-overlay_h)/2' if $settings->{watermark_position}=~/^(w|c|e)$/i;
         $y = 'main_h-overlay_h-'.$settings->{watermark_padding} if $settings->{watermark_position}=~/^(sw|s|se)$/i;
         my $vff = "overlay=$x:$y,".join(',', @vf); 
         $watermark=qq[-vf "movie=$watermark_logo [logo]; [in][logo] $vff [out]"] if -s $watermark_logo;
     }
     return $watermark;
}

sub EncodePreview
{
 my ($disk_id,$dx,$dir,$dir_uploads,$code,$real_id,$type,$width,$height,$length,$vfps, $settings) = @_;

 my $file = "$dir_uploads/$code\_$settings->{m_p_source}";
 unless(-f $file)
 {
    my $error = "File not found on disk: $file";
    $log->log($error);
    sendError($real_id,$error);
    return;
 }

 my $parts = $settings->{m_p_parts};
 my $dt = $parts>1 ? $length/($parts-1) : 1;
 my $dl = $settings->{m_p_length}/2;

 my $rand = join '', map int rand 10, 1..7;
 my $temp_dir = "$c->{cgi_dir}/temp/$disk_id/$rand";
 mkdir $temp_dir, 0777;

 if($parts*$settings->{m_p_length} > $length/2)
 {
    $parts = int( ($length/2)/$settings->{m_p_length} );
 }
 $parts=1 if $parts<1;

 my @arr;
 for my $i (0..$parts-1)
 {
     my $t = sprintf("%.0f",$i*$dt - $dl);
     $t = $length-$settings->{m_p_length}-5 if $i==($parts-1);
     $t = 5 if $i==0;
     next if $t<0;
     #-async 1 -fflags +igndts -fflags +genpts
     my $ffmpeg_string="$c->{ffmpeg} -ss $t -i $file -t $settings->{m_p_length} -c copy -bsf:v h264_mp4toannexb -f mpegts -y $temp_dir/p$i.ts";
     print"FFMPEG:$ffmpeg_string\n";
     `$ffmpeg_string`;
     push @arr, "$temp_dir/p$i.ts";
 }
 
 my $srcs=join '|', @arr;
 `$c->{ffmpeg} -i "concat:$srcs" -c copy -bsf:a aac_adtstoasc -movflags faststart -f mp4 -y $dir_uploads/$code\_p`;

 unlink(@arr);
 rmdir($temp_dir);

 return 0;
}

sub sendError
{
    my ($real_id,$error) = @_;
    my $ua = LWP::UserAgent->new(agent => $c->{user_agent}, timeout => 90);
    my $res = $ua->post("$c->{site_cgi}/fs.cgi",
                         {op              => "enc_error",
                          dl_key          => $c->{dl_key},
                          file_real_id    => $real_id,
                          error           => $error
                         });
}

# sub parseVideoInfo
# {
#     my ($file) = @_;
#     my @fields = qw(ID_LENGTH ID_VIDEO_WIDTH ID_VIDEO_HEIGHT ID_VIDEO_BITRATE ID_AUDIO_BITRATE ID_AUDIO_RATE ID_VIDEO_CODEC ID_AUDIO_CODEC ID_VIDEO_FPS);
#     my $info = join '', `mplayer "$file" -identify -frames 0 -quiet -ao null -vo null 2>/dev/null | grep ^ID_`;
#     my $f;
#     do{($f->{$_})=$info=~/$_=([\w\.]{2,})/is} for @fields;
#     $f->{ID_LENGTH} = sprintf("%.0f",$f->{ID_LENGTH});
#     ($f->{ID_VIDEO_FPS}) = $info=~/, ([\d\.]+) tbr,/i unless $f->{ID_VIDEO_FPS};
#     return $f;
# }