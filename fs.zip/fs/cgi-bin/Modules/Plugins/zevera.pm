package Plugins::zevera;

use strict;
use warnings;
use lib '..';
use lib '../Modules';
use XFSConfig;
use Plugin;
use base 'Plugin'; 
use HTTP::Request::Common qw(POST GET);
use MIME::Base64;
use XML::Simple;
use Data::Dumper;
use vars qw($VERSION);

$VERSION = "1.0" ;

our $options = {
		plugin_id => 2020,
		plugin_prefix=>'ze',
		domain=>'zevera.com',
		name=>'zevera',
		can_login => 0,
		upload=>0,
		download=>1,
};

sub check_link {
	shift;
	my $link = shift;
	if ($link =~ /(streamcloud\.eu|allmyvideos\.net|movshare\.net)/) {
		return 1;
	}
	return 0;
}

sub is_broken {
	my $self = shift;
	my $link = shift;
	$self->get($link);
	return 1 if($self->{content} =~ /this file has been removed/);
	return 0;
}

sub max_filesize {
	return 1024*1024*1024;
}

sub download {
	my $self = shift;
	my $url = shift;
	my $prefix = shift;
	my $update_stat = shift;
	my $req;
	my $response;
	my $dlink = '';
	$self->{action} = 'download';
	my $url2 = 'http://api.zevera.com/jDownloader.ashx?cmd=generatedownloaddirect&login='.$c->{zevera_login}.'&pass='.$c->{zevera_pass}.'&olink='.$url;
	print"UU:$url2\n";
        $req = GET $url2;
	my $ff = $self->direct_download($req, $url, $prefix, $update_stat);
	if($ff->{type} =~ /html/) {
		return {error=>-2, error_text=>'Cannot download direct link'};
	}
	return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};
}

1;
