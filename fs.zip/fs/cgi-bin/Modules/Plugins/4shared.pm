package Plugins::4shared;

use strict;
use warnings;
use lib '..';
use lib '../Modules';

use Plugin;
use base 'Plugin'; 
use HTTP::Request::Common qw(POST GET);
use Data::Dumper;
use vars qw($VERSION);

$VERSION = "1.6" ;

our $options = {
		plugin_id => 1026,
		plugin_prefix=>'4s',
		domain=>'4shared.com',
		name=>'fourshared',
		required_login=>1,
		can_login => 1,
		upload=>1,
		download=>1,
};

sub check_link {
	shift;
	my $link = shift;
	if ($link =~ /4shared\.com/) {
		return 1;
	}
	return 0;
}

sub is_broken {
	my $self = shift;
	my $link = shift;
	$self->get($link);
	return 1 if($self->{content} =~ /The file link that you requested is not valid/);
	return 0;
}

sub max_filesize {
	return 2024*1024*1024;
}
my $base = 'http://www.4shared.com';
sub login {
	my $self = shift;
	my $a = shift;
	$self->{action} = 'login';
	$self->{account} = $a;
	$self->get('https://www.4shared.com/login?callback=jsonp1327302742223&login='.$a->{login}.'&password='.$a->{password}.'&doNotRedirect=true');
	if($self->{content} =~ /loginRedirect":"([^\"]+)/) {
		my $u = $1;
		$self->get($u);
		$self->{content} =~ /AjaxFacade.rootDirId = (\d+)/;
		$self->{dirid} = $1;
		$self->{content} =~ /fpRedirParam : '([^\']+)'/;
		$self->{dirurl} = $1;
		return 1;
	}  
	
	
	return 0;
}


sub upload_file {
	my $self = shift;
	my $file = shift;
	my $filename = shift;
	my $description = shift;
	my $size = -s "$c->{filesdir}/$file";
	$self->{action} = 'upload';

	my ($mainDC) = $self->{content} =~ /mainDC.*value="(.*?)"/i;
#	my 
	my ($sid) = $self->{content} =~ /sId=(.*?)\"/;
	$self->get('http://www.4shared.com/');
	my ($done_url) = $self->{content} =~ m~top.location.href = '(http://www.4shared.com/account/home.jsp[^']*)~s;
	my ($action) = $self->{content} =~ /(http.*upload\d*\.jsp.*?)\"/i;
	$action =~ s/upload.jsp/upload5.jsp/;
	$action =~ s/&amp;/&/;
	print STDERR 'done_url'.$done_url;
#	my $req = POST 'http://www.4shared.com/rest/sharedFileUpload/create?dirId='.$self->{dirid}.'&name='.$filename.'&size='.$size;
#	$self->request($req);
	open FD, "< $c->{filesdir}/$file";
	binmode FD;
	my $rd = sub {read(FD, my $buf, 655535);return $buf;};
	my $req = HTTP::Request->new("POST",$action.'&keepName=false', [
		'x-root-dir'=>'-1',
		'x-file-name'=>$filename,
		'Content-Length'=>-s "$c->{filesdir}/$file",
		Content_Type => "application/octet-stream",
		Origin=>'http://4shared.com',
		Referer=>'http://4shared.com/',
		], $rd
		);
	$self->up_file($req);
	close FD;
	unless($self->{content} =~ /"uploadedFileId": (\d+)/) {
		my $text =~ /Cannot upload/;
		$text = 'You have insufficient free space' if($self->{content} =~ /you have insufficient free space/);
		return {error=>1, errortext=>$text};
	};
	my $fileid = $1;
	my $h = $self->getHT($done_url.$fileid);
	my $link = '';
#	$req = GET 'http://www.4shared.com/fileLinks/upload/view.asp?sId='.$sid.'&dl=true', Referer=>$done_url.$fileid;
#	my $h = $self->requestHT($req);
	my $ta = $h->look_down('_tag', 'a', 'id', qr/ml_file_$fileid/);
	my $link0 = $ta->{href};
	print STDERR $link0;
	($link) = $link0 =~ /openNewWindow\(\'([^\']+)/;
	return {download=>$link, remove=>''};
	
}
sub download {
	my $self = shift;
	my $url = shift;
	my $prefix = shift;
	my $update_stat = shift;
	my $req;
	my $response;
	my $dlink = '';
	$self->{action} = 'download';
	$req = GET $url;
	my $ff = $self->direct_download($req, $url, $prefix, $update_stat);
	if($ff->{type} =~ /html/) {
		$self->get($url);
		my $dlink = '';
		if($self->{content} =~ m~(http://[^\"]*/download/[^\'\"]+)~s) {
				$dlink = $1;
		} else {
			return {error=>-2, error_text=>'Cannot download direct link'};
		}
		$req = GET $dlink,Referer=>$url;
		$ff = $self->direct_download($req, $url, $prefix, $update_stat);
		return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}} unless($ff->{type}=~ /html/);
		
	}
	return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};
	

}

1;
