package Plugins::bitshare;

use strict;
use warnings;
use lib '..';
use Plugin;                                                                                                                                                                      
use base 'Plugin'; 
use HTTP::Request::Common qw(POST GET);
use Data::Dumper;
use vars qw($VERSION);

$VERSION = "1.6" ;

our $options = {
		plugin_id => 1021,
		plugin_prefix=>'bs',
		domain=>'bitshare.com',
		name=>'bitshare',
		can_login => 1,
		upload=>1,
		download=>1,
};

sub check_link {
	shift;
	my $link = shift;
	if ($link =~ /bitshare\.com/) {
		return 1;
	}
	return 0;
}

sub is_broken {
	my $self = shift;
	my $link = shift;
	$self->get($link);
	return 1 if($self->{content} =~ /this file has been removed/);
	return 0;
}

sub max_filesize {
	return 2048*1024*1024;
}
my $base = 'http://www.bitshare.com';
sub login {
	my $self = shift;
	my $a = shift;
	$self->{action} = 'login';
	my $req = GET 'http://bitshare.com/';
	$self->request($req);
	$base = $self->{response}->base();
	
	$req = POST "${base}/login.html",
	        Referer => "http://bitshare.com",
	       	Content => [user=>$a->{login}, password=>$a->{password}, submit=>' Login to your account '];	
	$self->request($req);
	if(($self->{response}->is_success) || ($self->{response}->code == 302)) {
		return 0 if($self->{content} =~ /No user found with such email/);
		return 0 if($self->{content} =~ /Login failed/);
		return 1;
	} else {
		return 0;
	}
}


sub upload_file {
	my $self = shift;
	my $file = shift;
	my $filename = shift;
	my $description = shift;
	$self->{action} = 'upload';
	my $h = $self->getHT('http://bitshare.com/');
	if(($self->{response}->is_success)) {
		my ($hostname) = 'bitshare.com';
		my $progress_id = $self->GRC;;
		my $form = $h->look_down('_tag', 'form', 'id',"uploadform");
		unless($form) {
			return {error=>1, errortext=>'Cannot upload'};		
		}
		my $action = $form->{action};
		my @inputs = $form->look_down('_tag', 'input');
		
		my %pcontent = map {$_->{name}=>$_->{value}} grep {$_->{name}}@inputs;
		$pcontent{'file[]'} = ["$c->{filesdir}/$file", $filename];
		$action = $action.'?X-Progress-ID=undefined'.$progress_id;
		open FD, "> $c->{filesdir}/${file}.add";
		close FD;
		my $req = POST $action,
	        	Referer => "http://bitshare.com/files/upload/",
			Content_Type => "multipart/form-data",
	        	Content => [
				'APC_UPLOAD_PROGRESS' => $pcontent{APC_UPLOAD_PROGRESS},
				'APC_UPLOAD_USERGROUP' => $pcontent{APC_UPLOAD_USERGROUP},
				'UPLOAD_IDENTIFIER' => $pcontent{UPLOAD_IDENTIFIER},
				'file[]'=>["$c->{filesdir}/${file}.add",'', 'Content-Type','application/octet-stream'],'file[]'=>["$c->{filesdir}/$file", $filename]];
		$self->up_file($req);
		unless($self->{content} =~ m~(http://bitshare.com/files/[^\n\r<]+)~s){ 
			return {error=>1, errortext=>'Cannot upload'};
		}
		my $uurl = $self->{response}->base();
		$req = GET $uurl, Referer=>$uurl;
		$self->request($req);
		my $link = $1;
		$self->get($link);
		my $remove = '';
		return {download=>$link, remove=>$remove};
		
	}
	
}
sub GRC {
	my $self = shift;
	my $length=32;
	my @letters=('a'..'f','k'..'o', 'u','p','q','r', 's','t','v','x','1'..'0');
	my $s = '';
	my $lettersLength = scalar(@letters);
	for(my $i = 0 ; $i < $length ; $i++) {
		$s.= $letters[int rand($lettersLength)];
	}
	return $s;
}
sub download {
	my $self = shift;
	my $url = shift;
	my $prefix = shift;
	my $update_stat = shift;
	my $req;
	my $response;
	my $dlink = '';
	$self->{action} = 'download';
	$req = GET $url;
	my $ff = $self->direct_download($req, $url, $prefix, $update_stat);
	if($ff->{type} =~ /html/) {
		return {error=>-2, error_text=>'Cannot download direct link'};
	}
	return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};
	

}

1;
