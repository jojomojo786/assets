package Plugins::oron;

use strict;
use warnings;
use lib '..';
use Plugin;                                                                                                                                                                      
use base 'Plugin'; 
use HTTP::Request::Common qw(POST GET);
use vars qw($VERSION);
$VERSION = "1.7" ;


our $options ={
		plugin_id => 1013,
		plugin_prefix=>'or',
		domain=>'oron.com',
		name=>'oron',
		can_login => 1,
		upload=>1,
		download=>1,
};

sub max_filesize {
	my $self = shift;
	my $a = 1000;
	$a = 2000 if($self->{logged});
	$a = 10000 if($self->{logged} && $self->{premium});
	return $a*1024*1024;
}

sub is_broken {
	my $self = shift;
	my $link = shift;
	$self->get($link);
	return 1 if($self->{content} =~ /File Not Found/);
	return 0;
}

sub check_link {
	shift;
	my $link = shift;
	if ($link =~ /oron\.com/) {
		return 1;
	}
	return 0;
}

sub login {
	my $self = shift;
	my $a = shift;
	$self->{action} = 'login';
	$self->get('http://oron.com/login');
	my $req = POST "http://oron.com/login",
	        Referer => 'http://oron.com/login',
       		Content => [login=>$a->{login}, password=>$a->{password}, op=>'login',redirect=>'', rand=>''];
	my $r = $self->request($req);
	if(($r->is_success) || ($r->code == 302)) {
		my $content = $self->{content};
		return 0 if($content =~ /Incorrect Login or Password/);
		return 1;

	} else {
		return 0;
	}
	return 1;
}

sub upload_file {
	my $self = shift;
	my $file = shift;
	my $filename = shift;
	my $description = shift;
	$self->{action} = 'upload';

	my $r = $self->get('http://oron.com');
	if(($r->is_success)) {
		my $h = HTML::TreeBuilder->new_from_content($self->{content});
		$h->ignore_unknown(0);
		$h = $h->elementify();
		my $form = $h->look_down('_tag', 'form', 'name', 'file');
		my @inputs = $form->look_down('_tag', 'input');
		my %pcontent;
		foreach my $i(@inputs) {
		             $pcontent{$i->{name}} = $i->{value} if($i && $i->{name} && $i->{value});
		}
		$pcontent{'tos'} = 1;
		$pcontent{'ut'} = 'file';
		$pcontent{'file_0'} = ["$c->{filesdir}/$file", $filename];
		my $rand = '';
		while (length($rand)<12) {$rand.=int(rand 10)}
		my $req = POST $form->{action}.'/?X-Progress-ID='.$rand,
			Referer=>'http://oron.com/',
			Content_Type => "multipart/form-data",
			Content => \%pcontent;;
		$req->header('TE'=>'');
		$self->up_file($req);
		$self->{content} =~ /'fn' value='([^\']+)'/;
		my $fn = $1;
		$req = POST 'http://oron.com',
			Referer=>$form->{action}.'/?X-Progress-ID='.$rand,
			Content=>[op=>'upload_result', fn=>$fn, st=>'OK'];
		$self->request($req);
		$self->{content} =~ m~href=\"([^\"]+)\"\s+class=\"btitle\"~;
		my $download = $1;
		$self->{content} =~ m~value=\"(http://oron.com[^\"]*?killcode[^\"]+)~s;
		my $delete = $1;
		$delete =~ s/[\n\r]//g;		
		return {download=>$download, remove=>$delete};
		
	}
}

sub download {
	my $self = shift;
	my $url = shift;
	my $prefix = shift;
	my $update_stat = shift;
	my $req;
	my $response;
	my $dlink = '';
	$self->{action} = 'download';
	my $h = $self->getHT($url);
	my $form = $h->look_down('_tag', 'form', 'name', 'F1');
	my @inputs = $form->look_down('_tag', 'input');
	my %pcontent;
	foreach my $i(@inputs) {
	             $pcontent{$i->{name}} = $i->{value} if($i && $i->{name} && $i->{value});
	}
	$h = $h->delete();
	$req = POST $url,
		Referer=>$url,
		Content=>[%pcontent];
	$h = $self->requestHT($req);
	my $link = $h->look_down('_tag', 'a', 'class', 'atitle');
	$dlink = $link->{href};
	$req = GET $dlink, Referer=>$url;
#	$self->request($req);
	my $ff = $self->direct_download($req, $dlink, $prefix, $update_stat);
	if($ff->{type} =~ /html/) {
		return {error=>-2, error_text=>'Cannot download direct link'};
	}
	return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};

}

1;
