package Plugins::hotfile;

use strict;
use warnings;
use lib '..';
use Plugin;                                                                                                                                                                      
use base 'Plugin'; 
use HTTP::Request::Common qw(POST GET);
use vars qw($VERSION);
$VERSION = "1.6" ;

our $options = {
		plugin_id => 1001,
		plugin_prefix=>'hf',
		domain=>'hotfile.com',
		name=>'hotfile',
		required_login=>1,
		can_login=>1,
		upload=>1,
		download=>1,
};


sub max_filesize {
	return 400*1024*1024;
}

sub is_broken {
	my $self = shift;
	my $link = shift;
	$self->get($link);
	return 1 if($self->{content} =~ /This file is either removed due to copyright claim or is deleted by the uploader/);
	return 0;
}

sub check_link {
	shift;
	my $link = shift;
	if ($link =~ /hotfile\.com/) {
		return 1;
	}
	return 0;
}

sub login {
	my $self = shift;
	my $a = shift;
	$self->{action} = 'login';
	my $rr = $browser->requests_redirectable();
	$browser->requests_redirectable([]); 

	$self->get('http://hotfile.com/');
	my $req = POST "http://hotfile.com/login.php",
	        Referer => "http://hotfile.com/",
	       	Content => [user=>$a->{login}, pass=>$a->{password}, returnto=>'/'];	
	$req->header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8');
	$self->request($req);
	$browser->requests_redirectable($rr); 
	if(($self->{response}->is_success) || ($self->{response}->code == 302)) {
		$self->get('http://hotfile.com/?cookiecheck=1');
		return 0 if($self->{content} =~ /�� ������ �����/);	
		return 1;

	} else {
		return 0;
	}
	return 1;
}
sub upload_file {
	my $self = shift;
	my $file = shift;
	my $filename = shift;
	my $description = shift;
	$self->{action} = 'upload';
	$self->get('http://hotfile.com/');
	if(($self->{response}->is_success)) {
		my $h = HTML::TreeBuilder->new_from_content($self->{content});
		$h->ignore_unknown(0);
		$h = $h->elementify();		
		my $form = $h->look_down('_tag', 'form', 'name', 'upForm');
		my @inputs = $form->look_down('_tag', 'input');
		
		my %pcontent = map {$_->{name}=>$_->{value}} grep {$_->{name}}@inputs;
		$pcontent{'uploads[]'} = ["$c->{filesdir}/$file", $filename];
		my $req = POST $form->{action},
	        	Referer => "http://hotfile.com/",
			Content_Type => "multipart/form-data",
	        	Content => \%pcontent;
		$self->up_file($req);
		unless($self->{content} =~ m~(https?://hotfile.com/dl[^\"]+)~s) {
			return {error=>1, errortext=>'Cannot upload'};
		}
		my $link = $1;
		$self->{content} =~ m~(https?://hotfile.com/kill[^\"]+)~s;
		my $remove = $1;
		return {download=>$link, remove=>$remove};
		
	}
	
}

sub download {
	my $self = shift;
	my $url = shift;
	my $prefix = shift;
	my $update_stat = shift;
	my $req;
	my $response;
	my $dlink = '';
	$self->{action} = 'download';
	$response = $self->get($url);
	unless ($response->is_success) {
		$log->write(2, $response->status_line);
		return {error=>1, error_text =>'Cannot get direct link'};
	}
	my $content = $response->content;
	if($content =~ /Such file does not exist /) {
		return {error=>-1, error_text=>'Such file does not exist'};
	}
	if( $content =~ m~(http://hotfile.com/get/[^\"]+)~s) {;
		$dlink = $1;
	} else {
		$log->write(3, $content);
	}
	if ($dlink) {
		$log->write(2, "dlink: $dlink");
		$req = GET $dlink;
		print STDERR "req0:".$req->as_string;
		my $ff = $self->direct_download($req, $dlink, $prefix, $update_stat);
		$log->write(2, 'type:'.$ff->{type});
		if($ff->{type} =~ /html/) {
			return {error=>-2, error_text=>'Cannot download direct link'};
		}
		return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};
	} else {
		return {error=>-4, error_text=>'Cannot get direct link'};
	}

}
1;
