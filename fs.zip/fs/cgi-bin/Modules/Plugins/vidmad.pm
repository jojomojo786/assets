package Plugins::vidmad;

use strict;
use warnings;
use lib '..';
use Plugin;                                                                                                                                                                      
use base 'Plugin'; 
use HTTP::Request::Common qw(POST GET);
use vars qw($VERSION);
$VERSION = "1.6" ;


our $options ={
		plugin_id => 1037,
		plugin_prefix=>'vm',
		domain=>'vidmad.net',
		name=>'vidmad',
		required_login=>0,
		can_login => 0,
		upload=>0,
		download=>1,
};

sub max_filesize {
	return 1000*1024*1024;
}


sub check_link {
	shift;
	my $link = shift;
	if ($link =~ /vidmad\.net/i) {
		return 1;
	}
	return 0;
}

sub download {
	my $self = shift;
	my $url = shift;
	my $prefix = shift;
	my $update_stat = shift;
	my $req;
	my $response;
	my $dlink = '';
	$self->{action} = 'download';

        $self->get($url);
        ($url) = $self->{content}=~/file:"(.+?)"/i;

	$req = GET $url;
	my $ff = $self->direct_download($req, $url, $prefix, $update_stat);

	if($ff->{type} =~ /html/) {
		return {error=>-2, error_text=>'Cannot download direct link'};
		
	}

	return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};

}

1;
