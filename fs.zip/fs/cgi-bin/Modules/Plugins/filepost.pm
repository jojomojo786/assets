package Plugins::filepost;

use strict;
use warnings;
use lib '..';
use Plugin;                                                                                                                                                                      
use base 'Plugin'; 
use HTTP::Request::Common qw(POST GET);
use vars qw($VERSION);
$VERSION = "1.6" ;


our $options ={
		plugin_id => 1012,
		plugin_prefix=>'fp',
		domain=>'filepost.com',
		name=>'filepost',
		required_login => 1,
		can_login => 1,
		upload=>1,
		download=>1,
};

sub max_filesize {
	my $self = shift;
	my $a = 1000;
	$a = 2000 if($self->{logged});
	$a = 10000 if($self->{logged} && $self->{premium});
	return $a*1024*1024;
}

sub is_broken {
	my $self = shift;
	my $link = shift;
	$self->get($link);
	return 1 if($self->{content} =~ /The requested file is not found/);
	return 0;
}

sub check_link {
	shift;
	my $link = shift;
	if ($link =~ /filepost\.com/ || $link =~ /fp\.com/) {
		return 1;
	}
	return 0;
}

sub login {
	my $self = shift;
	my $a = shift;
	$self->{action} = 'login';
	$self->get('http://filepost.com/');
	my $req = POST "http://filepost.com/general/login_form/?JsHttpRequest=".time.'-xml',
	        Referer => 'http://filepost.com/',
       	Content => [email=>$a->{login}, password=>$a->{password}];
	$self->request($req);
	if(($self->{response}->is_success) || ($self->{response}->code == 302)) {
		return 0 if($self->{content} =~ /������ ������������ email ��� ������/);
		return 0 if($self->{content} =~ /Введен неправильный email или пароль/);
		return 0 if($self->{content} =~ /captcha/);
		$self->get('http://filepost.com/');
		$self->{logged} = 1;
		$self->{premium} = 1 if($self->{content} =~ /Membership: Premium/);
		return 1;

	} else {
		return 0;
	}
}

sub upload_file {
	my $self = shift;
	my $file = shift;
	my $filename = shift;
	my $description = shift;
	$self->{action} = 'upload';
	my $r = $self->get('http://filepost.com/files/upload/');
	if(($r->is_success)) {
		$self->{content} =~ /upload_url: [\"\']([^\"\']+)/;
		my $upload_id = $1;
		my $upload_link = $1;
		$self->{content} =~ /SID: [\"\']([^\"\']+)/;
		my $sid = $1;
		$upload_link =~ s~\\~~g;
		$upload_link =~ s~\%([0-9A-F]{2})~chr(hex($1))~ge;
		$browser->agent('Shockwave Flash');
		my $req = POST $upload_link,
			Content_Type => "multipart/form-data",
	        	Content => [Filename=>"$filename", SID=>$sid, file=>["$c->{filesdir}/$file", $filename], Upload=>'Submit Query'];
		$self->up_file($req);
		$self->{content} =~ m~:\"([^\"]+)~;
		my $done_link = 'http://filepost.com/files/done/'.$1.'/?JsHttpRequest';
		my $h = $self->getHT($done_link);
		my $link = $h->look_down('_tag', 'input', 'id', 'down_link');
#		$self->{content} =~ /"link":"([^\"]+)"/;
		my $dlink = $link->{value};
		unless($dlink) {
			return {error=>1, errortext=>'Cannot upload'};
		}
		return {download=>$dlink, remove=>''};
		
	}
	
}

sub download {
	my $self = shift;
	my $url = shift;
	my $prefix = shift;
	my $update_stat = shift;
	my $req;
	my $response;
	my $dlink = '';
	$self->{action} = 'download';
	$req = GET $url;
	$self->request($req);
	my $code;	
	if($self->{content} =~ m~code: [\"\']([\da-z]+)[\"\']~) {
		$code = $1;
	}
	unless($code) {
		$log->write(2, 'free download');
		my $h = HTML::TreeBuilder->new_from_content($self->{content});
		$h->ignore_unknown(0);
		$h = $h->elementify();
		my $form = $h->look_down('_tag', 'form', 'id', 'downloadform');
		my $action = $form->{action};
		my @inputs = $form->look_down('_tag', 'input');
		my %pcontent = map {$_->{name}=>$_->{value}} grep {$_->{name}}@inputs;
		my $req = POST $form->{action},
	        	Referer => $url,
	        	Content => \%pcontent;
		$self->request($req);
		$h = $h->delete();		
		$self->{content} =~ m~code: "([\da-z]+)"~;
		$code = $1;
		$log->write(2, "sleep 60 seconds");
		sleep(60);
	}
	$log->write(2, "code: $code");
	$req = POST 'http://filepost.com/files/get/?JsHttpRequest='.time.int(rand(1000)).'-xml',
	        	Referer => $url,
			Content_Type => "application/octet-stream",
	        	Content => [action=>'get_link', code=>$code, pass=>'undefined'];
	$self->request($req);
	$self->{content} =~ /link\":\"([^\"]+)/;
	$dlink = $1;
	$dlink =~ s~\\~~g;
	$log->write(2, "dlink: $dlink");
	if(!$dlink || $dlink !~ m~http://~) {
		return {error=>-2, error_text=>'Cannot download direct link'};
	}
	$req = GET $dlink, Referer=>$url;
	my $ff = $self->direct_download($req, $dlink, $prefix, $update_stat);
	if($ff->{type} =~ /html/) {
		return {error=>-2, error_text=>'Cannot download direct link'};
	}
	return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};

}

1;
