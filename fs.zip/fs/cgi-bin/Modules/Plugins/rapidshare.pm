package Plugins::rapidshare;

use strict;
use warnings;
use lib '..';
use lib '../Modules';
use Plugin;                                                                                                                                                                      
use base 'Plugin'; 
use Digest::MD5::File qw/file_md5_hex/;
use HTTP::Request::Common qw(POST GET);
use Data::Dumper;
use vars qw($VERSION);
$VERSION = "1.6" ;

our $options = {
		plugin_id => 1003,
		plugin_prefix=>'rs',
		domain=>'rapidshare.com',
		name=>'rapidshare',
		required_login=>1,
		can_login => 1,
		upload=>1,
		download=>1,
};

sub max_filesize {
	return 2048*1024*1024;
}
sub is_broken {
	my $self = shift;
	my $link = shift;
	$self->get($link);
	return 1 if($self->{content} =~ /File not found/);
	return 0;
}

sub check_link {
	shift;                                                                                                                                                                       
	my $link = shift;                                                                                                                                                            
	if ($link =~ /rapidshare\.com/) {
		return 1;                                                                                                                                                                
	}                                                                                                                                                                            
	return 0; 
}

sub login {
	my $self = shift;
	my $a = shift;
	$self->{action} = 'login';
	$self->{last_account} = $a;
	return 1;
}


sub upload_file {
	my $self = shift;
	my $file = shift;
	my $filename = shift;
	my $description = shift;
	my $a = shift;
	$self->{action} = 'upload';

	$self->get('http://rapidshare.com');
	$self->get('http://api.rapidshare.com/cgi-bin/rsapi.cgi?sub=nextuploadserver');
	if(($self->{response}->is_success)) {
		my ($server_id) = $self->{content} =~ /(\d+)/;
		my $size = -s "$c->{filesdir}/$file";
		my $digest = file_md5_hex("$c->{filesdir}/$file");
#		$log->write(2,'md5:'.$digest);
		my $pcontent = {
				rsapi=>1,
				'sub'=>'upload',
				'md5hex'=>$digest,
				'complete'=>1,
				size=>$size,
				filecontent=>["$c->{filesdir}/$file", $filename]
			};
		if($a && $a->{login} && $a->{password}) {
			$pcontent->{login} = $a->{login};
			$pcontent->{password} = $a->{password};
		} else {
			return {error=>1, errortext=>'No login.Skipped'};
		}
		my $req = POST 'http://rs'.$server_id.'.rapidshare.com/cgi-bin/rsapi.cgi',
			Content_Type => "multipart/form-data; boundary=--632865735RS4EVER5675865",
	        	Content => $pcontent;				 
		$self->up_file($req);
		my ($link, $remove) = ('','');
		if ($self->{content} !~ /(COMPLETE|INCOMPLETE)\n(\d+),([^,]+),(\d+),(\w+)/) { return {error=>1, errortext=>'Cannot upload0'}; }

		my $recuploadtype = $1;
		my $recfileid = $2;
		my $recfilename = $3;
		my $recsize = $4;
		my $recmd5hex = $5;
		if($recuploadtype ne 'COMPLETE' ) {
			return {error=>1, errortext=>'Cannot upload'};
		} else {
			$link = "http://rapidshare.com/files/$recfileid/$recfilename"
		}
		$remove = '';
		return {download=>$link, remove=>$remove};
		
	}
}

sub download {
	my $self = shift;
	my $url = shift;
	my $prefix = shift;
	my $update_stat = shift;
	my $req;
	my $response;
	my $dlink = '';
	$self->{action} = 'download';
	$req = GET $url;
	$req->authorization_basic($self->{last_account}->{login},$self->{last_account}->{password}) if($self->{last_account});
	my $ff = $self->direct_download($req, $url, $prefix, $update_stat);
	$log->write(2, 'type:'.$ff->{type});
	if($ff->{type} =~ /html/) {#direct download don't enable or user not premium
		$self->get($url);
		$self->{content} =~ /!download\|(.+?)\|(\d+)\|(.+?)\|(\d+)/i;
		my ($fileid, $filename) = ($2, $3);
		$self->get("http://api.rapidshare.com/cgi-bin/rsapi.cgi?sub=download&fileid=$fileid&filename=$filename&try=1");
		unless($self->{content} =~ /ERROR: You need to wait/) {
			my @data = split(':', $self->{content});
			if($data[0] eq 'DL') {
				my @details = split(',', $data[1]);
				my $host = $details[0];
				my $dlauth = $details[1];
				my $count = $details[2];
				sleep($count) if($count);
				$dlink =  'http://'.$host."/cgi-bin/rsapi.cgi?sub=download&editparentlocation=0&bin=1&fileid=$fileid&filename=$filename&dlauth=".$dlauth;
				$log->write(2, "free dlink: $dlink");
				$req = GET $dlink;
				$ff = $self->direct_download($req, $url, $prefix, $update_stat);
				$log->write(2, 'type:'.$ff->{type});
				unless($ff->{type} =~ /html/) {
					return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};
				}
			}
		}
		return {error=>-2, error_text=>'Cannot download direct link'};
	}
	return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};
}

1;
