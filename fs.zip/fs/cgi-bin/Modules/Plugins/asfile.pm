package Plugins::asfile;

use strict;
use warnings;
use lib '..';
use Plugin;                          
                                                                                                                                           
use base 'Plugin'; 
use HTTP::Request::Common qw(POST GET);
use MIME::Base64;
use XML::Simple;
use Data::Dumper;
use vars qw($VERSION);

$VERSION = "1.6" ;

our $options = {
		plugin_id => 1032,
		plugin_prefix=>'as',
		domain=>'asfile.com',
		name=>'asfile',
		required_login=>1,
		can_login => 1,
		upload=>1,
		download=>1,
};

sub check_link {
	shift;
	my $link = shift;
	if ($link =~ /asfile\.com/) {
		return 1;
	}
	return 0;
}

sub is_broken {
	my $self = shift;
	my $link = shift;
	$self->get($link);
	return 1 if($self->{content} =~ /this file has been removed/);
	return 0;
}

sub max_filesize {
	return 5*1024*1024*1024;
}
sub login {
	my $self = shift;
	my $a = shift;
	$self->{action} = 'login';
	my $req = GET 'http://asfile.com/en/login';
	$self->request($req);
#	$base = $self->{response}->base();
	
	$req = POST "http://asfile.com/en/login",
	        Referer => "http://asfile.com/en/login/",
	       	Content => [login=>$a->{login}, password=>$a->{password}];	
	$self->request($req);
	$self->{account} = $a;
#	if(($self->{response}->is_success) || ($self->{response}->code == 302)) {
#		return 0 if($self->{content} =~ /No user found with such email/);
#		return 0 if($self->{content} =~ /Login failed/);
		return 1;
#	} else {
#		return 0;
#	}
}


sub upload_file {
	my $self = shift;
	my $file = shift;
	my $filename = shift;
	my $description = shift;
	$self->{action} = 'upload';
	my $h = $self->getHT('http://asfile.com/en/');
	my $form = $h->look_down('_tag', 'form', 'id', 'upload');
	my $action = $form->{action};
	my $token = $form->look_down('_tag','input', 'name', 'token');
	my $req = POST $action,
		Content_Type => "multipart/form-data",
	       	Content => ['file[]'=>["$c->{filesdir}/$file", $filename], token=>$token->{value}, agree=>1];
	$self->up_file($req);
	my $remove = '';
	my $link = '';
	if($self->{content} =~ /\"path\"\:\"([^\"]+)/) {
		$link = 'http://asfile.com/file/'.$1;
	}
	return {download=>$link, remove=>$remove};
		
	
}
sub download {
	my $self = shift;
	my $url = shift;
	my $prefix = shift;
	my $update_stat = shift;
	my $req;
	my $response;
	my $dlink = '';
	$self->{action} = 'download';
	$req = GET $url;
	my $ff = $self->direct_download($req, $url, $prefix, $update_stat);
	if($ff->{type} =~ /html/) {
		my $ourl = $url;
		$url =~ s~file/~en/premium-download/file/~;
		$req = GET $url, Referer=>$ourl;
		$self->request($req);
#		<a href="http://s24.asfile.com/file/premium/acda7948a0e768086f38a57064783146/1335426291/LhQfs6l/IE.desktop">Download</a>
		$self->{content} =~ /\<a href="([^"]+)\"\>Download/s;
		my $dlink = $1;
		print STDERR "$dlink\n";
		$req = GET $dlink;
		my $ff = $self->direct_download($req, $url, $prefix, $update_stat);
		if($ff->{type} =~ /html/) {
			return {error=>-2, error_text=>'Cannot download direct link'};
		} 
	}
	return {error=>0, filename=>$ff->{filename}, filesize=>$ff->{filesize}};
	

}

1;
