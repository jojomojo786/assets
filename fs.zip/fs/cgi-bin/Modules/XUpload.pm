package XUpload;

use strict;
use lib '.';
use XFSConfig;
use Digest::MD5;
use LWP::UserAgent;
use File::Copy;
use Encode;
use vars qw($log);
use File::Find;
use File::Basename;
use IPC::Open3;

$c->{ffmpeg}||="$c->{cgi_dir}/ffmpeg";

sub ImportDir
{
   my ($path, %opts) = @_;

   delete $opts{op};
   my $usr_id=$opts{usr_id};
   delete $opts{usr_id};

   $path =~ s/\/+$//;

   die("No path") if !$path;

  find({ wanted => \&wanted, no_chdir => 1 }, $path);
  
  sub wanted
  {
     next unless -f $File::Find::name;
     next unless $File::Find::name=~/\.($c->{video_extensions})$/i;
     my $fld_path = $1 if $File::Find::dir =~ /^\Q$path\E\/(.*)/;
      my $xfile = { file_tmp => $File::Find::name, file_name_orig => basename($File::Find::name), usr_id=>$usr_id };
      my $ff = ProcessFile($xfile, { ip => '2.2.2.2', fld_path => "$opts{prefix}/$fld_path", %opts });
  }
}

# file_tmp, file_name_orig, file_descr, file_public
# optional: usr_id, no_limits
sub ProcessFile
{
   my ($file,$f) = @_;

   $f->{ip}||=$ENV{REMOTE_ADDR};

   unless($log)
   {
     require Log;
     $log = Log->new(filename=>'upload.txt', mute=>1);
   }

   unless(-f $file->{file_tmp})
   {
      $file->{file_status}="No file on disk ($file->{file_tmp})";
      return $file;
   }

   unless($file->{file_name_orig}=~/\.($c->{video_extensions})$/i)
   {
      $file->{file_status}="Not video file($file->{file_name_orig})";
      return $file;
   }

   $file->{file_size} = -s $file->{file_tmp};

   open(FILE,$file->{file_tmp})||die"cant open file";
   my $data;
   read(FILE,$data,4096);
   seek(FILE,-4096,2);
   read(FILE,$data,4096,4096);
   $file->{md5} = Digest::MD5::md5_base64 $data;

   $file->{file_spec} = getVideoInfo($file->{file_tmp},$f,$file->{file_name_orig});

   $file->{data_srt} = getVideoSRTs($file->{file_tmp},$f) if $c->{srt_auto};

   unless($f->{ID_VIDEO_WIDTH}=~/^\d+$/i)
   {
      $file->{file_status}="Not video file format";
      return $file;
   }

   $file->{file_length} = $f->{ID_LENGTH};

   $f->{fld_name}=~s/[\"\<\>\0]+//g;
   $f->{file_ip} = $f->{ip};

   my %extra;
   $extra{$_}=$f->{$_} for grep{/^extra_/} keys %$f;

   my $effects = join '|', map{/^eff_(.+)$/;"$1=$f->{$_}"} grep{/^eff_/ && $f->{$_}} keys %$f;

   ##### LWP
   LWPFS:
   my $ua = LWP::UserAgent->new(agent => $c->{user_agent}, timeout => 90);
   my $res = $ua->post("$c->{site_cgi}/fs.cgi",
                       {
                       dl_key       => $c->{dl_key},
                       %$f,
                       host_id      => $c->{host_id},
                       #disk_id      => $f->{disk_id},
                       file_title   => $file->{file_title},
                       file_name    => $file->{file_name_orig},
                       file_descr   => $file->{file_descr},
                       file_size    => $file->{file_size},
                       file_public  => $file->{file_public},
                       file_adult   => $file->{file_adult},
                       rslee        => $file->{rslee},
                       file_md5     => $file->{md5},
                       file_spec    => $file->{file_spec},
                       #file_spec_txt=> $f->{file_spec_txt},
                       file_length  => $file->{file_length},
                       usr_id       => $file->{usr_id},
                       no_limits    => $file->{no_limits},
                       sid          => $f->{sid},
                       api_key      => $f->{api_key},
                       #torrent      => $file->{torrent}||$f->{torrent},
                       #sess_id      => $f->{sess_id}||'',
                       #file_ip      => $f->{ip},
                       #fld_name     => $f->{fld_name},
                       #file_category=> $f->{file_category},
                       cat_id       => $file->{cat_id},
                       tags         => $file->{tags},
                       usr_login    => $file->{usr_login}||'',
                       usr_id       => $file->{usr_id}||'',
                       url_queue_id => $file->{url_queue_id}||'',
                       file_src     => $file->{url}||'',
                       effects      => $effects,
                       data_srt     => $file->{data_srt},
                       %extra,
                       }
                      );
   my $info = $res->content;
   $log->log("INFO:$info");

   if($extra{'retry'}<2 && (!$res->is_success || !$info=~/^\d+:/))
   {
      $log->log("Bad response. Let's try one more time.");
      sleep 1;
      $extra{'retry'}++;
      goto LWPFS;
   }

   ($file->{file_id},$file->{file_code},$file->{file_real},$file->{utype},$file->{msg},$file->{extra}) = $info=~/^(\d+):(\w+):(\w+):(\w+):(.*?)\n(.*)$/s;

   if($file->{msg} ne 'OK')
   {
      $file->{file_status}=$file->{msg}||$info;
      $file->{file_status}="fs.cgi error" if $file->{file_status}=~/Software error/i;
      return $file;
   }

   if(!$file->{file_code})
   {
      $file->{file_status}="error connecting to DB";
      return $file;
   }

   my $extra;
   for(split /\n/, $file->{extra})
   {
      /^(.+?)=(.*)$/;
      $extra->{$1}=$2;
   }

   $file->{disk_id} ||= $f->{disk_id} || $extra->{disk_id};
   &SaveFile( $file, $ua, $f, $extra ) if $file->{file_code} eq $file->{file_real};
   return $file;
}

########

sub SaveFile
{
   my ($file,$ua,$f,$extra) = @_;
   my $dx = sprintf("%05d",$file->{file_id}/$c->{files_per_folder});
   $file->{dx} = $dx;
   my $dir = "$c->{cgi_dir}/orig/$file->{disk_id}/$dx";
   my $dirup = "$c->{cgi_dir}/uploads/$file->{disk_id}/$dx";
   
   unless(-d $dir)
   {
      my $mode = 0777;
      mkdir($dir,$mode) || do{$log->log("Fatal Error: Can't mkdir ($!)");&xmessage("Fatal Error: Can't mkdir ($!)")};
      chmod $mode,$dir;
   }
   unless(-d $dirup)
   {
      my $mode = 0777;
      mkdir($dirup,$mode) || do{$log->log("Fatal Error: Can't mkdir ($!)");&xmessage("Fatal Error: Can't mkdir ($!)")};
      chmod $mode,$dirup;
   }

   my $file_dst = "$dir/$file->{file_code}";
   if($extra->{newmode})
   {
      $file_dst = "$dirup/$file->{file_code}_$extra->{newmode}";
   }

   move($file->{file_tmp},$file_dst) || 
      copy($file->{file_tmp},$file_dst) || 
         do{
               my $error = "Can't copy file from temp dir ($file->{file_tmp})($file_dst)($!)";
               $ua->post("$c->{site_cgi}/fs.cgi",
                          {dl_key    => $c->{dl_key},
                           op        => 'delete_file_db',
                           file_id   => $file->{file_id},
                          });
               if($file->{url_queue_id})
               {
                  $file->{file_status}=$error;
                  return;
               }
               $log->log($error);
               &xmessage($error);
           };
   my $mode = 0666;
   chmod $mode, $file_dst;
   unlink($file->{file_tmp}) if -e $file->{file_tmp};
   symlink($file_dst, "$dir/$file->{file_code}") if $extra->{newmode} && $extra->{symorig} && !-e "$dir/$file->{file_code}";

   # Postprocess original MP4 video
   if($extra->{newmode} && $file->{file_name_orig}=~/\.mp4$/i)
   {
    rename($file_dst,"$file_dst.mp4");
    saferunstr("$c->{mp4box_path} -add $file_dst.mp4 -isma -inter 2000 $file_dst.mp4x");
    move( "$file_dst.mp4x", $file_dst ) if -f "$file_dst.mp4x";
    rename("$file_dst.mp4",$file_dst) unless -e $file_dst;
   }
   # elsif($extra->{newmode} && $file->{file_name_orig}=~/\.flv$/i)
   # {
   #  my $rr = `$c->{cgi_dir}/yamdi -i $file_dst -o $file_dst.flv 2>&1`;
   #  move( "$file_dst.flv", $file_dst ) if -f "$file_dst.flv";
   # }

   my $idir = "$c->{htdocs_dir}/i/$file->{disk_id}/$dx";
   $mode = 0777;
   unless(-d $idir)
   {
      mkdir($idir,$mode);
      chmod $mode, $idir;
   }

   my $rand = join '', map int rand 10, 1..7;
   my $temp_dir = "$c->{cgi_dir}/temp/$rand";
   mkdir $temp_dir, 0777;

   $c->{thumb_position} = sprintf("%.1f",$file->{file_length}*$1/100) if $c->{thumb_position}=~/^([\d\.]+)%$/;
   $c->{thumb_position}=5 unless $c->{thumb_position}=~/^[\d\.]+$/;
   $c->{thumb_position}=3 if $c->{thumb_position}<3;

   if($c->{custom_snapshot_upload} && $file->{snapshot_file_tmp})
   {
      saferunstr("convert -resize 2000x2000\> -strip $file->{snapshot_file_tmp} $idir/$file->{file_code}.jpg") if -f $file->{snapshot_file_tmp} && -s $file->{snapshot_file_tmp} < $c->{custom_snapshot_upload}*1073741824;
   }
   else
   {
      my $thw = 720 if $f->{ID_VIDEO_WIDTH}>720;
      makeSnap($file_dst, "$idir/$file->{file_code}.jpg", $c->{thumb_position}, $thw, 0, 'fast');
   }
   
   saferunstr("convert $idir/$file->{file_code}.jpg -resize $c->{thumb_width}x$c->{thumb_height}^ -gravity center -extent $c->{thumb_width}x$c->{thumb_height} -quality $c->{thumb_quality} $idir/$file->{file_code}_t.jpg");
   unless(-f "$idir/$file->{file_code}_t.jpg")
   {
       makeSnap($file_dst, "$idir/$file->{file_code}_t.jpg", $c->{thumb_position}, $c->{thumb_width}, $c->{thumb_height}, 'fast');
   }
   
   copy("$c->{htdocs_dir}/i/default.jpg","$idir/$file->{file_code}.jpg")   unless -e "$idir/$file->{file_code}.jpg";
   copy("$c->{htdocs_dir}/i/default.jpg","$idir/$file->{file_code}_t.jpg") unless -e "$idir/$file->{file_code}_t.jpg";

   #$dir = "$c->{cgi_dir}/uploads/$file->{disk_id}/$dx" unless -f "$dir/$file->{file_code}";

   #if( $c->{m_x} && !($c->{m_x_prem_only} && $file->{utype} ne 'prem') )
   createScreenlist($file_dst,$file,$f,$temp_dir,$idir) if $extra->{screenlist};

   unlink(<$temp_dir/*.png>);
   unlink(<$temp_dir/*.jpg>);

   unlink(<$temp_dir/*.png>);
   unlink(<$temp_dir/*.jpg>);
   rmdir($temp_dir);
}

sub makeSnap
{
    my ($file_path, $final_path, $timestamp, $resize_w, $resize_h, $fast, $instant) = @_;
    unlink($final_path);

        $resize_h||='-1' if $resize_w;
        my $size = "-vf scale=$resize_w:$resize_h" if $resize_w && $resize_h;
        #my $extra = '-noaccurate_seek' if $fast;
        my $timeout='timeout 10s ' unless $c->{no_ffmpeg_timeout};
        my ($ss1,$ss2);
        if($fast){ $ss1="-ss $timestamp -noaccurate_seek"; } else { $ss2="-ss $timestamp"; }
        my $str = "$timeout$c->{ffmpeg} $ss1 -i $file_path $ss2 -an -dn -sn -r 1 -vframes 1 -y $size -qscale 3 $final_path";
        return $str if $instant;
        my $x = `$str >/dev/null 2>/dev/null`; #-f mjpeg 2>&1
        #my $x = saferunstr( $str );
        return $x;
}

sub createScreenlist
{
    my ($file_path,$file,$f,$temp_dir,$idir) = @_;
    my $bgcolor='#e9e9e9';
    my $text_color='#303030';
    my $logo_color='#F6F6F6';
    my $prewidth = 1020;
    my $vsize = 338;
    my $vborder = 2;
    if ($c->{m_x_width}==1280)
    {
       $prewidth = 1278;
       $vsize = 424;
       $vborder = 1;
    }
    $c->{m_x_rows}||=3;
    my $frames=3*$c->{m_x_rows};
    my @scmd;
    for my $i (1..$frames)
    {
       my $ss = sprintf("%.1f",$i*$file->{file_length}/($frames+1));
       my $out = makeSnap($file_path, "$temp_dir/".sprintf("%03d",$i).".jpg", $ss, $vsize, 0, 'fast', 'instant');
       push @scmd, "$out >/dev/null 2>/dev/null" if $out;
    }
    system( join(';',@scmd) );

    `montage -background "$bgcolor" $temp_dir/0*.jpg -tile 3x -geometry +1+1 $temp_dir/11.png`;
    unlink(<$temp_dir/0*.jpg>);

    my $file_size = $file->{file_size} || -s $file_path;
    my $fsize = makeFileSize($file_size);
    $file->{file_length2} = sprintf("%02d:%02d:%02d",int($file->{file_length}/3600),int(($file->{file_length}%3600)/60),$file->{file_length}%60);
    my $info="File Name: $file->{file_name_orig}\n";
    $info.="File Size: $fsize ($file_size bytes)\n";
    $info.="Resolution: $f->{ID_VIDEO_WIDTH}x$f->{ID_VIDEO_HEIGHT}\n";
    $info.="Duration: $file->{file_length2} ($file->{file_length} seconds)";
    my $top_size = $prewidth."x70";
    my $stamp=qq[-gravity East -fill '$logo_color' -font $c->{cgi_dir}/Modules/fonts/font_arialblack.ttf -pointsize 36 -weight Bold -annotate +30-1 '$c->{m_x_logo}'] if $c->{m_x_logo};
    `convert -size $top_size xc:$bgcolor -gravity NorthWest -fill "$text_color" -font $c->{cgi_dir}/Modules/fonts/font_tahoma.ttf -pointsize 13 -weight Normal -annotate +4+0 "$info" $stamp $temp_dir/22.png`;
    my $border=$vborder;
    #`montage -background "$bgcolor" -border $border -bordercolor "$bgcolor" $temp_dir/22.png $temp_dir/11.png -mode concatenate -tile 1x -strip -quality 85 $temp_dir/33.jpg`;
    `convert -bordercolor "$bgcolor" $temp_dir/22.png $temp_dir/11.png -append -strip -border $border -quality 85 $idir/$file->{file_code}_x.jpg`;
    $c->{m_x_th_width}||=400;
    $c->{m_x_th_height}||=400;
    `convert $temp_dir/11.png -thumbnail '$c->{m_x_th_width}x$c->{m_x_th_height}' -strip -quality 80 $idir/$file->{file_code}_xt.jpg`;

    unlink("$temp_dir/11.png");
    unlink("$temp_dir/22.png");
}

sub createTimeslides
{
    my ($file_path, $file,$f,$temp_dir,$idir) = @_;

    my $slide_size = '108x60';

    my $rand = join '', map int rand 10, 1..7;
    my $temp_dir = "$c->{cgi_dir}/temp/$rand";
    mkdir $temp_dir, 0777;


    my $frames=$c->{m_z_cols}*$c->{m_z_rows};
    for my $i (1..$frames)
    {
       my $ss = sprintf("%.1f",$i*$file->{file_length}/($frames+1));
       my $th = "$temp_dir/".sprintf("%03d",$i);
       my $thp = "$temp_dir/p".sprintf("%03d",$i);
       makeSnap( $file_path, "$th\_s.png", $ss, $c->{thumb_width}, $c->{thumb_height}, 'fast');
       copy("$th\_s.png","$th\_p.png");
    }
    
    #`mogrify -thumbnail '$slide_size!' $temp_dir/*_s.png`; #
    
    #-background "$bgcolor"
    my $zfile = "$idir/$file->{file_code}"."0000.jpg";
    `montage $temp_dir/*_s.png -tile $c->{m_z_cols}x -geometry +0+0 $zfile`;
    #copy($zfile, "$idir/$file->{file_code}\_p.jpg");

    #`montage $temp_dir/*_p.png -tile $c->{m_z_cols}x -geometry +0+0 $idir/$file->{file_code}\_p.jpg`;

    unlink(<$temp_dir/*.png>);
    unlink(<$temp_dir/*.jpg>);
    rmdir($temp_dir);
}

sub xmessage
{
   my ($msg) = @_;
   $msg=~s/'/\\'/g;
   $msg=~s/<br>/\\n/g;
   print"Content-type: text/html\n\n";
   print"<HTML><HEAD><Script>alert('$msg');</Script></HEAD><BODY><b>$msg</b></BODY></HTML>";
   exit;
}

sub makeFileSize
{
   my ($size)=@_;
   return '' unless $size;
   return "$size Bytes" if $size<=1024;
   return sprintf("%.0f Kb",$size/1024) if $size<=1024*1024;
   return sprintf("%.01f Mb",$size/1048576) if $size<=1024*1024*1024;
   return sprintf("%.01f Gb",$size/1073741824);
}

sub getVideoInfo
{
	my ($file_tmp,$f,$filename) = @_;
	return '' unless -s $file_tmp;
	my $file_spec;
	my $info_json = `$c->{cgi_dir}/ffprobe -v quiet -print_format json -show_format -show_streams "$file_tmp"`;
	return '' unless $info_json=~/^\{/;
	require JSON;
	$info_json=~s/,\n\s+"disposition": \{.+?\}//gs;
 	my $x = JSON::decode_json($info_json);

 	$f->{file_spec_txt} = $info_json;
 	$f->{file_spec_json} = $x;
 	$f->{ID_LENGTH} = sprintf("%.02f", $x->{format}->{duration}||60*30 );
 	$f->{ID_DEMUXER} = $x->{format}->{format_name};
 	$f->{ID_DEMUXER}='mp4' if $f->{ID_DEMUXER}=~/mp4/i;

 	my @videos = grep{$_->{codec_type} eq "video"} @{$x->{streams}};
 	my @audios = grep{$_->{codec_type} eq "audio"} @{$x->{streams}};
 	my @subs   = grep{$_->{codec_type} eq "subtitle" && $_->{codec_name}!~/^(hdmv_pgs_subtitle|dvd_subtitle)$/i} @{$x->{streams}};

 	my $v = $videos[0];
 	my $a = $audios[0];

 	$v->{avg_frame_rate}=~s/\/1$//;
 	($f->{ID_VIDEO_WIDTH}, $f->{ID_VIDEO_HEIGHT}, $f->{ID_VIDEO_BITRATE}, $f->{ID_VIDEO_CODEC}, $f->{ID_VIDEO_FPS}) = ($v->{width}, $v->{height}, sprintf("%.0f",$v->{bit_rate}/1000), $v->{codec_name}, $v->{avg_frame_rate});

 	($f->{ID_AUDIO_BITRATE}, $f->{ID_AUDIO_RATE}, $f->{ID_AUDIO_CODEC}) = (sprintf("%.0f",$a->{bit_rate}/1000), $a->{sample_rate}, $a->{codec_name});

 	if(!$v->{bit_rate} && $x->{format}->{bit_rate}){ $f->{ID_VIDEO_BITRATE}=sprintf("%.0f", ($x->{format}->{bit_rate}-$a->{bit_rate})/1000 ); }

	my @fields = qw(ID_LENGTH ID_VIDEO_WIDTH ID_VIDEO_HEIGHT ID_VIDEO_BITRATE ID_AUDIO_BITRATE ID_AUDIO_RATE ID_VIDEO_CODEC ID_AUDIO_CODEC ID_VIDEO_FPS ID_DEMUXER);
 	$file_spec = join('|', map{$f->{$_}}@fields );

 	$f->{srt}=1 if @subs;

   return $file_spec;
}

sub getVideoInfoOld
{
   my ($file_tmp,$f,$filename) = @_;
   my $file_spec;
   my @fields = qw(ID_LENGTH ID_VIDEO_WIDTH ID_VIDEO_HEIGHT ID_VIDEO_BITRATE ID_AUDIO_BITRATE ID_AUDIO_RATE ID_VIDEO_CODEC ID_AUDIO_CODEC ID_VIDEO_FPS ID_DEMUXER);

   if($c->{vid_info_parser} eq 'mplayer' || !$c->{vid_info_parser})
   {
       my $info = saferunstr("mplayer $file_tmp -identify -frames 0 -quiet -ao null -vo null 2>/dev/null | grep ^ID_");
       do{($f->{$_})=$info=~/$_=([\w\.]{2,})/is} for @fields;
       $f->{ID_LENGTH} = sprintf("%.0f",$f->{ID_LENGTH});
       ($f->{ID_VIDEO_FPS}) = $info=~/, ([\d\.]+) tbr,/i unless $f->{ID_VIDEO_FPS};
       $f->{ID_VIDEO_CODEC}='XVID' if $info=/ID_VIDEO_FORMAT=XVID/i;
       $f->{ID_VIDEO_BITRATE}=int($f->{ID_VIDEO_BITRATE}/1000);
       $f->{ID_AUDIO_BITRATE}=int($f->{ID_AUDIO_BITRATE}/1000);
   }
   else
   {
       #my $info = saferunstr("$c->{ffmpeg} -i $file_tmp"); # 2>&1
       my $info = `$c->{ffmpeg} -i "$file_tmp" 2>&1`;
       ($f->{file_spec_txt}) = $info=~/(Input #.+)$/is;
       $f->{file_spec_txt}=~s/\nAt least one.+$//i;

       ($f->{ID_AUDIO_RATE}) = $info=~/, (\d+) Hz,/i;
       ($f->{ID_VIDEO_WIDTH},$f->{ID_VIDEO_HEIGHT}) = $info=~/, (\d{3,4})x(\d{3,4})/i;
       my ($durH,$durM,$durS) = $info=~/Duration: (\d+):(\d+):(\d+)/i;
       $f->{ID_LENGTH} = $durH*3600 + $durM*60 + $durS;
       ($f->{ID_AUDIO_BITRATE}) = $info=~/Audio:.+?, (\d+) kb\/s/i;
       ($f->{ID_VIDEO_BITRATE}) = $info=~/, (\d+) kb\/s,/i;
       unless($f->{ID_VIDEO_BITRATE})
       {
           ($f->{ID_VIDEO_BITRATE}) = $info=~/bitrate: (\d+) kb\/s/i;
           $f->{ID_VIDEO_BITRATE} = $f->{ID_VIDEO_BITRATE}-$f->{ID_AUDIO_BITRATE} if $f->{ID_VIDEO_BITRATE};
       }
       ($f->{ID_AUDIO_RATE}) = $info=~/, (\d+) Hz,/i;
       ($f->{ID_VIDEO_CODEC}) = $info=~/Video: (.+?)[\(\,]/i;
       #$f->{ID_VIDEO_CODEC}=$1 if $f->{ID_VIDEO_CODEC}=~/\((\w+) \//i;
       ($f->{ID_AUDIO_CODEC}) = $info=~/Audio: (\w+?)[\,\s]/i;
       ($f->{ID_DEMUXER}) = $info=~/Input #\d+, (.+?), from/i;
       ($f->{ID_VIDEO_FPS})   = $info=~/, ([\d\.]+) tbr,/i;
       ($f->{ID_VIDEO_FPS}) ||= $info=~/, ([\d\.]+) fps,/i;
       $f->{srt}=1 if $info=~/Subtitle: (ass|srt|webvtt)/i;
       ($f->{video_map}) = $info=~/Stream #(\d+:\d+).*: Video:/i;
	   my @as;
	   push @as,$1 while $info=~/Stream #(\d+:\d+).+?: Audio:/ig;
	   $f->{audio_map} = \@as;

       $file_spec = join('|', map{$f->{$_}}@fields );
   }
   $f->{ID_VIDEO_CODEC}=~s/^ffo//gi;
   $f->{ID_VIDEO_CODEC}=~s/^ff//gi;
   $f->{ID_VIDEO_CODEC}=~s/(^\s+|\s+$)//gi;
   $f->{ID_VIDEO_CODEC}='MPEG2' if $f->{ID_VIDEO_CODEC} eq 'mpeg2video';
   $f->{ID_AUDIO_CODEC}='AAC' if $f->{ID_AUDIO_CODEC}=~/^(faad|faac)$/i;
   $f->{ID_AUDIO_CODEC}='PCM' if $f->{ID_AUDIO_CODEC}=~/^PCM_\w+/i;
   $f->{ID_VIDEO_FPS}=~s/\.000$//;
   $f->{ID_DEMUXER}='mp4' if $f->{ID_DEMUXER}=~/(mp4|m4a)/i;
   $f->{ID_DEMUXER}='' unless $f->{ID_DEMUXER}=~/^avi|flv|mp4|mkv|mpeg|wmv$/i;
   $f->{ID_DEMUXER}||=$f->{vid_container};
   $f->{ID_DEMUXER}||='flv' if $filename=~/\.flv$/i;
   $f->{ID_DEMUXER}||='mp4' if $filename=~/\.mp4$/i;
   $f->{ID_VIDEO_BITRATE}||=128;

   $file_spec = join('|', map{$f->{$_}}@fields );

   return $file_spec;
}

sub getVideoSRTs
{
  my ($file_tmp,$f) = @_;
  my $txt = `$c->{ffmpeg} -i $file_tmp 2>&1`;
  my @arr;
  while($txt=~/Stream #(\d+:\d+)\((\w+)\): Subtitle/gi)
  {
    my $srt = `$c->{ffmpeg} -i "$file_tmp" -vn -an -map $1 -f webvtt -`;
    push @arr, "$2|||$srt";
  }
  while($txt=~/Stream #(\d+:\d+): Subtitle/gi)
  {
    my $srt = `$c->{ffmpeg} -i "$file_tmp" -vn -an -map $1 -f webvtt -`;
    push @arr, "eng|||$srt";
  }
  return join('^^^',@arr);
}

sub saferun
{
   my (@args) = @_;
   my $pid = open3(\*WRFH, \*RDFH, \*ERRFH, @args) || die("Couldn't open: $!");
   #my $pid = open3(\*WRFH, \*RDFH, \*RDFH, @args) || die("Couldn't open: $!");
   my $str = join('', <RDFH>);
   #$str .= join('', <ERRFH>);
   my $status = waitpid($pid, 1);
   return $str;
}

sub saferunstr
{
   my ($str) = @_;
   return saferun( split(/\s+/,$str) );
}

1;
